import { Route, Switch } from 'react-router-dom';
import Loader from 'app/components/loader';
import React from 'react';
import Login from 'app/pages/Login';
import ForgotPassword from 'app/pages/forgotPassword';
import Customer from 'app/pages/dashboard/index';
import Header from '../containers/header/index';
import ProtectedRoute from 'app/utils/protectedRoutes';

const Router = () => {
  return (
    <React.Suspense fallback={<Loader />}>
      <Header />
      <Switch>
        <Route exact path='/' component={Login} />
        <Route exact path='/forgotPassword' component={ForgotPassword} />
        <ProtectedRoute exact path='/customer' component={Customer} />
      </Switch>
    </React.Suspense>
  );
};

export default Router;
