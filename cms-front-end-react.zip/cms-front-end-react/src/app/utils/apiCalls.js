import { fetchCall, fetchLoginCall, fetchFileUploadCall } from '../utils/ajax';
import { API_CONSTANTS, API_METHODS } from '../constants/api-constant';

export const getLoginDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.LOGIN_DATA}`;
  return fetchLoginCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getForgotPasswordDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.FORGOT_PASSWORD}`;
  return fetchLoginCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getChangePasswordDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.CHANGE_PASSWORD}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const getOtpDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.OTP_VERIFICATION}`;
  return fetchLoginCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getRefreshToken = (callback, payload) => {
  const url = `${API_CONSTANTS.REFRESH_TOKEN}`;
  return fetchLoginCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getLogoutDetail = (callback) => {
  const url = `${API_CONSTANTS.LOG_OUT}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST);
};

export const getUserList = (callback, payload) => {
  const url = `${API_CONSTANTS.USER_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getResetPasswordDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.RESET_PASSWORD}`;
  return fetchLoginCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const getBlockUserDetail = (callback, payload) => {
  const url = `${API_CONSTANTS.BLOCK_USER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const getUnBlockUserDetail = (callback, payload) => {
  const url = `${API_CONSTANTS.UNBLOCK_USER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const getUserRequestList = (callback) => {
  const url = `${API_CONSTANTS.GET_USER_REQUEST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getServiceRequestList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_SERVICE_REQUEST_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const updateServiceRequest = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_SERVICE_REQUEST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const getTrendingTopicList = (callback) => {
  const url = `${API_CONSTANTS.GET_TRENDING_TOPIC_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getVideoList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_VIDEO_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const updateVideo = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_VIDEO}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const createVideo = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_VIDEO}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const deleteVideo = (callback, payload) => {
  const url = `${API_CONSTANTS.REMOVE_VIDEO}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const getFeedbackList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_FEEDBACK_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getArticleList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_ARTICLE_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const updateArticle = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_ARTICLE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const createArticle = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_ARTICLE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const deleteArticle = (callback, payload) => {
  const url = `${API_CONSTANTS.REMOVE_ARTICLE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const getContactUsReasonList = (callback) => {
  const url = `${API_CONSTANTS.GET_REASON_CONTACTUS_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getServicerequestReasonList = (callback) => {
  const url = `${API_CONSTANTS.GET_REASON_SERVICEREQUEST_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const createReason = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_REASON}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getRoleList = (callback) => {
  const url = `${API_CONSTANTS.GET_ROLE_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const updateRole = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_ROLE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const createRole = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_ROLE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const deleteRole = (callback, payload) => {
  const url = `${API_CONSTANTS.REMOVE_ROLE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const getTermsAndCondition = (callback) => {
  const url = `${API_CONSTANTS.GET_TERMS__CONDITIONS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const updateTermsAndCondition = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_TERMS_CONDITION}`;
  return fetchFileUploadCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const getUserRequestContactUsList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_USER_REQUEST_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getNotificationList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_NOTIFICATION_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const createNotification = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_NOTIFICATION}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const getFAQList = (callback) => {
  const url = `${API_CONSTANTS.GET_FAQ_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const createFAQ = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_FAQ}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const updateFAQ = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_FAQ}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const deleteFAQ = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_FAQ}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const getBannerList = (callback) => {
  const url = `${API_CONSTANTS.GET_BANNER_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const createBanner = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_BANNER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const deleteBanner = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_BANNER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const updateBanner = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_BANNER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};
//machines page apis

export const getMachineCategoryMakeWiseList = (callback) => {
  const url = `${API_CONSTANTS.GET_MACHINES_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const updateMachine = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_MAKE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const updateMachineCategory = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_MACHINE_CATEGORY}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const createMachineCategory = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_MACHINE_CATEGORY}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getMachineCategoryList = (callback) => {
  const url = `${API_CONSTANTS.GET_MACHINES_CATEGORY_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const deleteMachineCategory = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_MACHINE_CATEGORY}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const createMachineCategoryModel = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_MACHINE_CATEGORY_MODEL}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const deleteModel = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_MODEL}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const uploadImageFile = (callback, payload) => {
  const url = `${API_CONSTANTS.FILE_UPLOAD}`;
  return fetchFileUploadCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getPageList = (callback) => {
  const url = `${API_CONSTANTS.GET_PAGE_LIST}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getCodesAndManualsList = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_CODES_MANUALS_LIST}?limit=${payload.limit}&page=${payload.page}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
}

export const updateCodesManuals = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_CODES_MANUALS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.PUT, payload);
};

export const uploadCodeFiles = (callback, payload) => {
  const url = `${API_CONSTANTS.UPLOAD_CODES}`;
  return fetchFileUploadCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const uploadManualFiles = (callback, payload) => {
  const url = `${API_CONSTANTS.UPLOAD_MANUALS}`;
  return fetchFileUploadCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const deleteCodesManualsFolder = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_CODES_MANUALS_FOLDER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};

export const deleteCodesManualsFile = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_CODES_MANUALS_FILE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.DELETE, payload);
};