import React, { useEffect, useState } from 'react';
import MultiSelect from 'react-multiselect-checkboxes';
import Confirm from '../../components/confirmModal/confirm';
import DateTime from 'datatables.net-datetime';
import './index.scss';
import { getUserList, getBlockUserDetail, getUnBlockUserDetail } from '../../utils/apiCalls';
import Loader from '../../components/loader';
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

//Datatable Modules
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
// import 'datatables.net-colreorderwithresize-npm/ColReorderWithResize';
import jsZip from 'jszip';
import 'datatables.net-buttons/js/buttons.html5.min';
import 'datatables.net-buttons/js/buttons.print.min';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
window.JSZip = jsZip;

const CommonTable = () => {
  const [alertText, setAlertText] = useState('');
  const [blockUserId, setBlockUserId] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [columnsList, setColumnsList] = useState();
  const [dataList, setDataList] = useState();
  const [hideTable, setHideTable] = useState(false);
  const [showUserConfirmModal, setShowUserConfirmModal] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [hideColumnList, setHideColumnList] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isShowHideOptions, setIsShowHideOptions] = useState(false);
  const [filteredColumnValues, setFilteredColumnValues] = useState([]);

  const getData = () => {
    setIsShowLoader(true);
    let payload = {
      length: 500
    }
    getUserList((response) => {
      const { success, message, data } = response;
      setIsShowLoader(false);
      if (success && data?.data?.length) {
        let columnNames = [];
        var values = data.data;
        //         values.forEach((val)=>{
        //           if(val.createdAt || val.updatedAt)
        //           {
        // var date = new Date(val.createdAt);
        // var date1 = new Date(val.updatedAt);
        //   val.createdAt = (date.getFullYear() + '-' + date.getUTCMonth() + '-' + date.getDate());
        //   val.updatedAt = (date1.getFullYear() + '-' + date1.getMonth() + '-' + date1.getDate());
        //           }
        //         });
        columnNames = Object.keys(values[0]);
        var column = [];
        let hideValues = [];
        for (var i in columnNames) {
          let columnObj = {
            data: columnNames[i],
            title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1)
          }
          if (columnNames[i] === 'MachineCategories') {
            columnObj.className = 'noExport';
          }
          column.push(columnObj);
          if (columnNames.length - 1 == i) {
            let obj = {
              title: 'Actions',
              className: 'noExport'
            }
            column.push(obj);
          }
          let obj1 = {};
          obj1 = {
            label: columnNames[i], value: columnNames[i], id: parseInt(i) + 1, checked: true
          }
          hideValues.push(obj1);
          if (columnNames.length - 1 == i) {
            obj1 = {
              label: 'Actions', value: 'Actions', id: parseInt(i) + 2, checked: true
            }
            hideValues.push(obj1);
          }
        }
        setHideTable(true);
        setHideColumnList(hideValues);
        setColumnsList(column);
        setDataList(values);
      } else if (!success) {
        setAlertText(message);
        setShowConfirmModal(true);
        setHideTable(false);
      }
    }, payload);
  };

  useEffect(() => {
    if (hideTable) {

      $(document).ready(function () {
        if ($.fn.dataTable.isDataTable('#data-table')) {
          $('#data-table').DataTable().columns().visible(true);
          $('#data-table').DataTable().destroy();
          $('#data-table').empty();
        }
        var table = $('#data-table')
          .DataTable({
            bRetrieve: true,
            data: dataList,
            columns: columnsList,
            paging: true,
            responsive: true,
            ordering: true,
            buttons: [
              {
                extend: 'collection', text: '', className: 'common-table__export-btn',
                buttons: [
                  {
                    extend: 'csv', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'excel', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'pdf', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  }
                ],
              },
            ],
            columnDefs: [
              {
                data: null,
                sortable: false,
                orderable: false,
                render: function (data, type, row, meta) {
                  var splitRowObject = data.id;
                  var userStatus = data.userStatus;
                  return '<div class="common-table__dots-parent"><button class="fa fa-ellipsis-v common-table__dots" type="button" data-toggle ="' + userStatus + '" data-target="' + meta.row + '"></button><div class="table-menu table-menu__left"   id="' + meta.row + '"><button id="' + splitRowObject + '" type="button" class="table-menu__item">Block User</button><button id="' + splitRowObject + '" type="button"  class="table-menu__modal">UnBlock User</button><div class="table-menu__arrow-right"></div></div></div>'
                },
                targets: [-1]
              }
            ],
            stateSave: true,
            oLanguage: { sProcessing: '<div class="loader" ></div>' },
            'bPaginate': true,
            'bFilter': true,
            'bJQueryUI': true,
            'bLengthChange': true,
            'bStateSave': true,
            'bDeferRender': true,
            'bAutoWidth': true,
            order: [[1, 'asc']],
            dom: 'ifrtlpB',
            // 'processing': true,
            // 'serverSide': true,
            // 'ajax': {
            // 'url': `${API_CONSTANTS.USER_LIST}`,
            //   'url': 'http://13.233.18.99:8201/philips/v1/api/getUserListDataTable',
            //   'type': 'POST',
            //   'error': handleAjaxError,
            //   // 'success': handleAjaxSuccess,
            //   'beforeSend': function (xhr) {
            //     xhr.setRequestHeader('Authorization', token);
            //   },
            //   'dataSrc': function (json) {
            //     return json.data.data;
            //   }
            // },
            // searchDelay: 350,
          });

        handleResetColumns(false);
        toggleAllColumns(hideColumnList, true, false);

        $(window).on('click', function () {
          $('.table-menu').hide();
        });

        $('#data-table tbody').on('click', '.common-table__dots', function (e) {
          e.stopPropagation();
          var btnId = $(this).attr('data-target');
          var userStatus = $(this).attr('data-toggle');
          var popUpId = '#' + btnId;
          if ($(popUpId).css('display') == 'none') {
            $('.table-menu').hide();
          }
          if (popUpId) {
            $(popUpId).toggle();
          }
          if (userStatus === 'active') {
            $('.table-menu').removeClass('table-menu__left-unblock');
            $('.table-menu__modal').hide();
            $('.table-menu__item').show();
            $('.table-menu').addClass('table-menu__left');
          } else if (userStatus === 'block') {
            $('.table-menu').removeClass('table-menu__left');
            $('.table-menu__item').hide();
            $('.table-menu__modal').show();
            $('.table-menu').addClass('table-menu__left-unblock');
          }
        });

        $('#data-table tbody').on('click', '.table-menu__item', function () {
          setShowUserConfirmModal(true);
          var Id = $(this).attr('id');
          setBlockUserId(Id);
        });

        $('#data-table tbody').on('click', '.table-menu__modal', function () {
          var userId = $(this).attr('id');
          if (userId) {
            handleUnblokUser(userId);
          }
        });
        
        // date range filter
        var fromDate, toDate, fromUpdatedDate, toUpdatedDate;
        fromDate = new DateTime($('#min'), {
          format: 'YYYY-MM-DD'
        });
        toDate = new DateTime($('#max'), {
          format: 'YYYY-MM-DD'
        });

        fromUpdatedDate = new DateTime($('#min_updated'), {
          format: 'YYYY-MM-DD'
        });
        toUpdatedDate = new DateTime($('#max_updated'), {
          format: 'YYYY-MM-DD'
        });

        handleFilterDateRange(fromDate, toDate, fromUpdatedDate, toUpdatedDate);

        // Refilter the table
        $('#min, #max').on('change', function () {
          debugger;
          fromUpdatedDate.s.display = null;
          toUpdatedDate.s.display = null;
          table.draw();
        });

        $('#min_updated, #max_updated').on('change', function () {
          fromDate.s.display = null;
          toDate.s.display = null;
          table.draw();
        });

        $('#from_date').click(function () {
          document.getElementById('from_date') ? document.getElementById('from_date').style.display = 'none' : null;
          document.getElementById('date_popup') ? document.getElementById('date_popup').style.display = 'flex' : null;
        });

        $('#clear_created_date').click(function () {
          fromDate.s.d = null;
          toDate.s.d = null;
          fromDate.s.display = null;
          toDate.s.display = null;
          document.getElementById('min').value = '';
          document.getElementById('max').value = '';
          fromUpdatedDate.s.display = fromUpdatedDate.s.d;
          toUpdatedDate.s.display = toUpdatedDate.s.d;
          handleFilterDateRange(fromDate, toDate, fromUpdatedDate, toUpdatedDate);
          document.getElementById('date_popup') ? document.getElementById('date_popup').style.display = 'none' : null;
          document.getElementById('from_date') ? document.getElementById('from_date').style.display = 'block' : null;
          $.fn.dataTable.ext.search.pop();
          table.draw();
        });

        $('#updated_date').click(function () {
          document.getElementById('updated_date') ? document.getElementById('updated_date').style.display = 'none' : null;
          document.getElementById('updated_date_popup') ? document.getElementById('updated_date_popup').style.display = 'flex' : null;
        });

        $('#clear_updated_date').click(function () {
          fromUpdatedDate.s.d = null;
          toUpdatedDate.s.d = null;
          fromUpdatedDate.s.display = null;
          toUpdatedDate.s.display = null;
          document.getElementById('min_updated').value = '';
          document.getElementById('max_updated').value = '';
          fromDate.s.display = fromDate.s.d;
          toDate.s.display = toDate.s.d;
          handleFilterDateRange(fromDate, toDate, fromUpdatedDate, toUpdatedDate);
          document.getElementById('updated_date_popup') ? document.getElementById('updated_date_popup').style.display = 'none' : null;
          document.getElementById('updated_date') ? document.getElementById('updated_date').style.display = 'block' : null;
          $.fn.dataTable.ext.search.pop();
          table.draw();
        });
        // date range filter ends

      });
      setIsShowHideOptions(true);
    } else {
      getData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataList]);

  const handleUnblokUser = (userId) => {
    let payload = {
      userId: userId
    }
    getUnBlockUserDetail((response) => {
      const { success, message } = response;
      if (success === true) {
        getData();
        setAlertText('User  has been Unblocked!');
        setShowConfirmModal(true);
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
        $('.table-menu').hide();
      }
    }, payload);
  }

  const userBlockConfirmModal = () => {
    setShowUserConfirmModal(false);
    if (blockUserId) {
      let payload = {
        userId: blockUserId
      }
      getBlockUserDetail((response) => {
        const { success, message } = response;
        if (success === true) {
          getData();
          setAlertText('User has been Blocked!');
          setShowConfirmModal(true);
          $('.table-menu').hide();
        } else {
          setAlertText(message);
          setShowConfirmModal(true);
          $('.table-menu').hide();
        }
      }, payload);
    }
  }
  
  const handleFilterDateRange = (fromDate, toDate, fromUpdatedDate, toUpdatedDate) => {
    $.fn.dataTable.ext.search.push(
      function (settings, data) {
        if (settings.nTable.id !== 'data-table') {
          return true;
        }
        var fromSearchdate = fromUpdatedDate.val();
        var toSearchdate = toUpdatedDate.val();
        var date = new Date(data[21]);
        var fromdate = fromDate.s.display ? fromDate.val() : (fromUpdatedDate.s.display ? fromSearchdate : null);
        var todate = toDate.s.display ? toDate.val() : (toUpdatedDate.s.display ? toSearchdate : null);
        if (fromUpdatedDate.s.display || toUpdatedDate.s.display) {
          date = new Date(data[22]);
        }
        if (fromdate || todate) {
          if ((fromdate === null && date?.valueOf() <= todate?.valueOf()) ||
            (fromdate?.valueOf() <= date?.valueOf() && todate === null) ||
            (fromdate?.valueOf() <= date?.valueOf() && date?.valueOf() <= todate?.valueOf())
          ) {
            return true;
          }
        } else if (fromdate === null && todate === null) {
          return true;
        }
        return false;
      }
    );
  }

  const getDropdownButtonLabel = ({ placeholderButtonLabel, value }) => {
    if (value && value.some((o) => o.value === '*')) {
      return `${placeholderButtonLabel}: All`;
    } else {
      const values = [];
      value.map((val, i) => {
        if (i < value.length - 1) {
          values.push(val.value);
          val.checked = false;
        }
      });
      values.splice(0, 0, value[value.length - 1]?.value);
      return `${placeholderButtonLabel}: ${values.join(',')}`;
    }
  };

  const handleResetColumns = (isFromToggleColumns) => {
    if (isFromToggleColumns) {
      $('#data-table').DataTable().columns().visible(true);
      $('#data-table thead tr:eq(1)').remove();
    }
    $('#data-table thead tr').clone(true).appendTo('#data-table thead');
    $('#data-table thead tr:eq(1) th').each(function (i) {
      var title = $(this).text();
      $(this).off('click.DT');
      $(this).removeAttr('aria-controls');
      $(this).removeAttr('aria-sort');
      $(this).removeClass(
        'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
      );
      if (title !== 'Actions') {
        if (title === 'CreatedAt') {
          $(this).html(
            '<button id="from_date">Select Range</button><div id="date_popup" style="display:flex" ><div ><span class="common-table__range"><label class="common-table__label">From Date:</label><input readOnly type="text" id="min" name="min" /></span><span class="common-table__range"><label class="common-table__label">To Date:</label><input readOnly type="text" id="max" name="max" /></span></div><i id="clear_created_date" class="fas fa-times overlay__cross-icon common-table__cross-btn" ></i></div>'
          );
        } else if (title === 'UpdatedAt') {
          $(this).html(
            '<button id="updated_date">Select Range</button><div id="updated_date_popup" style="display:flex" ><div><span class="common-table__range"><label class="common-table__label">From Date:</label><input readOnly type="text" id="min_updated" name="min_updated" /></span><span class="common-table__range"><label class="common-table__label">To Date:</label><input readOnly type="text" id="max_updated" name="max_updated" /></span></div><i id="clear_updated_date" class="fas fa-times overlay__cross-icon common-table__cross-btn" ></i></div>'
          );
        } else {
          $(this).html(
            '<input type="text" placeholder="Search ' + title + '" />'
          );
          $('input', this).on('keyup change', function () {
            if ($('#data-table').DataTable().column(i).search() !== this.value) {
              $('#data-table').DataTable().column(i).search(this.value).draw();
            }
          });
        }
        document.getElementById('date_popup') ? document.getElementById('date_popup').style.display = 'none' : null;
        document.getElementById('updated_date_popup') ? document.getElementById('updated_date_popup').style.display = 'none' : null;
      }
      else {
        $(this).html(
          <th ></th>
        );
      }
    });
    if (!isFromToggleColumns) {
      $('#data-table thead tr:eq(0) th').each(function (i) {
        if (i === columnsList.length - 1) {
          $(this).removeAttr('aria-controls');
          $(this).removeAttr('aria-sort');
          $(this).removeClass(
            'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
          );
        }
      });
    }
  }

  const toggleAllColumns = (value, isShowColumn, isHideSearch) => {
    if ($.fn.dataTable.isDataTable('#data-table')) {
      handleResetColumns(true);
    }
    let values = [];
    value.map((val) => {
      val.checked = false;
      var valId = val.id - 1;
      if ((val.label !== 'id') && (val.label !== 'MachineCategories')) {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
        values.push(val);
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
    if (values?.length !== 0) {
      setFilteredColumnValues(values);
      setSelectedOptions([
        { label: 'All', value: '*' },
        ...values,
      ]);
    }
  };

  const toggleColumn = (value, isShowColumn, isHideSearch) => {
    var valId = value.id - 1;
    $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
    $('#data-table thead tr:eq(1) th').each(function () {
      if ((value.label !== 'id') && (value.label !== 'MachineCategories')) {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
  };

  const onChange = (value, event) => {
    if (event.action === 'select-option' && event.option.value === '*') {
      toggleAllColumns(hideColumnList, true, false);
      setSelectedOptions([{ label: 'All', value: '*' }, ...filteredColumnValues]);
    } else if (
      event.action === 'deselect-option' &&
      event.option.value === '*'
    ) {
      toggleAllColumns(hideColumnList, false, true);
      setSelectedOptions([]);
    } else if (event.action === 'deselect-option') {
      toggleColumn(event.option, false, true);
      setSelectedOptions(value.filter((o) => o.value !== '*'));
    } else {
      toggleColumn(event.option, true, false);
      if (filteredColumnValues.length === value.length) {
        setSelectedOptions([{ label: 'All', value: '*' }, ...value]);
      } else {
        setSelectedOptions(value);
      }
    }
  };

  return (
    <div className='common-table'>
      {isShowHideOptions &&
        <div className='common-table__toggle'>
          <MultiSelect
            options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
            placeholderButtonLabel='Show '
            getDropdownButtonLabel={getDropdownButtonLabel}
            value={selectedOptions}
            onChange={onChange}
            setState={setSelectedOptions}
            hideSearch={true}
          />

        </div>
      }
      <table id='data-table' className='display' width='100%'></table>

      {
        showUserConfirmModal && (
          <Confirm buttonText={'OK'} isCancelRequired={true} confirmTitle={'Are you sure you want to Block the User?'}
            onConfirm={() => { userBlockConfirmModal() }} onCancel={() => { setShowUserConfirmModal(false) }} />
        )
      }
      {
        showConfirmModal && (
          <Confirm buttonText={'OK'} confirmTitle={alertText} isCancelRequired={false}
            onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
        )
      }
      {isShowLoader && <Loader />}
      {/*     //   date-range popup */}
      {/* {isShowDateRangePopup &&
        <div className='overlay overlay__index' id='dialog-range-popup' onClick={handleClick}>
          <div className='overlay__table common-table__popup'>
            <div className='common-table__popup__container'>
              <div className='overlay__dialog__title'>
                <div className='overlay__dialog__title__cancelBackground__cancel-box overlay__cancel' onClick={() => setIsShowDateRangePopup(false)}>
                  <span className='overlay__dialog__title__cancelBackground__cross overlay__dialog__title__cancelBackground__right-arrow'></span>
                  <span className='overlay__dialog__title__cancelBackground__cross overlay__dialog__title__cancelBackground__left-arrow'></span>
                </div>
              </div>
              <div className='overlay__dialog__elements'>
                <div className='pageHeader common-table__popup__header'>
                  <Name title='Select Range' />
                  <div className='notification__btn'>
                    <Button id='add-video' className='pageHeader__button notification__width done-button'
                      buttonClick={(e) => { handleDoneClick() }}>
                      Done
                    </Button>
                  </div>
                </div>
                <table border='0' cellSpacing='5' cellPadding='5'>
                  <tbody><tr>
                    <td>From Date:</td>
                    <td><input readOnly type='text' id='min' name='min'></input></td>
                  </tr>
                    <tr>
                      <td>To Date:</td>
                      <td><input readOnly type='text' id='max' name='max'></input></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      } */}
      {/*     //   date-range popup ends */}
    </div >
  );
};

CommonTable.propTypes = {
};

CommonTable.defaultProps = {
};

export default React.memo(CommonTable);
