import React, { useState } from 'react';
import './index.scss';
import Button from '../../components/button/index';
import '../../components/button/index.scss';
import { useHistory } from 'react-router-dom';
import { regex } from '../../constants/regex';
import logo from '../../../assets/images/phillips-logo.svg';
import Confirm from '../../components/confirmModal/confirm';
import {
  getForgotPasswordDetails,
  getOtpDetails,
  getResetPasswordDetails,
} from '../../utils/apiCalls';
import Loader from '../../components/loader';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isBtnDisabled, setIsBtnDisabled] = useState(true);
  const [isToggle, setIsToggle] = useState(false);
  const [isShowEmail, setIsShowEmail] = useState(false);
  const [placeHolder, setPlaceholder] = useState('Enter Email');
  const history = useHistory();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [isShowLoader, setIsShowLoader] = useState(false);

  const handleActions = () => {
    setIsShowLoader(true);
    if (placeHolder === 'Enter Email') {
      const payload = {
        email: email,
      };
      getForgotPasswordDetails((response) => {
        const { success, message } = response;
        if (success === true) {
          setAlertText('An invitation sent to your Email!');
          setShowConfirmModal(true);
          setPlaceholder('Enter Otp');
        } else {
          setPlaceholder('Enter Email');
          if (alertText !== message) {
            setAlertText(message);
            setShowConfirmModal(true);
          }
        }
        setIsShowLoader(false);
      }, payload);
      setIsBtnDisabled(true);
      document.getElementById('forgot_Common_Field').value = '';
    } else if (otp && placeHolder === 'Enter Otp' && !isShowEmail) {
      const otpPayload = {
        otp: otp,
        email: email,
      };
      if (otpPayload) {
        getOtpDetails((response) => {
          const { success, message } = response;
          if (success === true) {
            setAlertText('Your One time password is verified!');
            setShowConfirmModal(true);
            setIsShowEmail(true);
          } else if (success === false) {
            setIsShowEmail(false);
            setPlaceholder('Enter Otp');
            if (alertText !== message) {
              setAlertText(message);
              setShowConfirmModal(true);
            }
          }
          setIsShowLoader(false);
        }, otpPayload);
      }
      document.getElementById('forgot_Common_Field').value = '';
      setIsBtnDisabled(true);
    } else if (isShowEmail) {
      const resetPasswordPayload = {
        newPassword: newPassword,
        email: email,
      };
      const timeout = 3000;
      if (resetPasswordPayload) {
        getResetPasswordDetails((response) => {
          const { success, message } = response;
          if (success === true) {
            setAlertText('Your password has been changed successfully!');
            setShowConfirmModal(true);
            setTimeout(() => {
              history.push('/');
            }, timeout);
          } else {
            if (alertText !== message) {
              setAlertText(message);
              setShowConfirmModal(true);
            }
          }
          setIsShowLoader(false);
        }, resetPasswordPayload);
      }
    }
  };

  const validateEmail = (Email) => {
    const emailRegex = regex.emailRegex;
    return emailRegex.test(Email);
  };

  const validateOtp = (Otp) => {
    const otpRegex = regex.otpRegex;
    return otpRegex.test(Otp);
  };

  const inputHandler = (event, key) => {
    let val = event?.target.value;
    setIsBtnDisabled(true);
    if (key === 1 && placeHolder === 'Enter Email') {
      setEmail(val);
      if (validateEmail(val)) {
        setIsBtnDisabled(false);
      }
    } else if (key === 1 && placeHolder === 'Enter Otp') {
      setOtp(val);
      if (validateOtp(val)) {
        setIsBtnDisabled(false);
      }
    } else if (key === 2) {
      setEmail(val);
    } else if (key === 3) {
      setNewPassword(val);
    }
    if (validateEmail(email) && newPassword) {
      setIsBtnDisabled(false);
    }
  };

  const handleKeyEnter = (e) => {
    if (e.key === 'Enter' && validateEmail(email) && newPassword) {
      handleActions();
    }
  };

  const handleToggle = () => {
    setIsToggle(!isToggle);
  };

  return (
    <div className='ForgotPassword'>
      {!isShowEmail ? (
        <div className='ForgotPassword__container'>
          <div className='ForgotPassword__wrapper'>
            <img
              src={logo}
              alt='Phillip-Logo'
              className='ForgotPassword__logo'
            />
            <div className='u_display_flex u_align_items ForgotPassword__width70 ForgotPassword__header'>
              <div className='ForgotPassword__input__width'>
                <input
                  required
                  type='text'
                  id='forgot_Common_Field'
                  onKeyDown={(event) => {
                    handleKeyEnter(event);
                  }}
                  onChange={(e) => inputHandler(e, 1)}
                  className='ForgotPassword__input'
                  placeholder={placeHolder}
                ></input>
              </div>
            </div>
            <Button
              className='ForgotPassword__button'
              isBtnDisabled={isBtnDisabled}
              buttonClick={() => {
                handleActions();
              }}
            >
              {placeHolder === 'Enter Email' ? 'SUBMIT' : 'CONFIRM'}
            </Button>
          </div>
          {showConfirmModal && alertText && (
            <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
              onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
          )}
        </div>
      ) : (
        <div className='ForgotPassword__container'>
          <div className='ForgotPassword__wrapper'>
            <img
              src={logo}
              alt='Phillip-Logo'
              className='ForgotPassword__logo'
            />
            <div className='u_display_flex u_align_items ForgotPassword__width70'>
              <div className='ForgotPassword__input__width'>
                <input type='password' style={{ display: 'none' }} />
                <input
                  required
                  type='text'
                  onKeyDown={(event) => {
                    handleKeyEnter(event);
                  }}
                  onChange={(e) => inputHandler(e, 2)}
                  className='ForgotPassword__input'
                  placeholder='Enter Email'
                />
              </div>
            </div>
            <div className='u_display_flex u_align_items ForgotPassword__width70'>
              <div className='ForgotPassword__input__width'>
                <input
                  required
                  type={`${isToggle ? 'text' : 'password'}`}
                  onKeyDown={(event) => {
                    handleKeyEnter(event);
                  }}
                  onChange={(e) => inputHandler(e, 3)}
                  className='ForgotPassword__input'
                  placeholder='Enter New Password'
                />
                <span
                  role='button'
                  className={`${isToggle
                    ? 'fa fa-eye-slash ForgotPassword__icon'
                    : 'fa fa-eye ForgotPassword__icon'
                    }`}
                  onClick={() => {
                    handleToggle();
                  }}
                  onKeyDown={() => {
                    handleToggle();
                  }}
                ></span>
              </div>
            </div>
            <Button
              className='ForgotPassword__button'
              isBtnDisabled={isBtnDisabled}
              buttonClick={() => {
                handleActions();
              }}
            >
              SUBMIT
            </Button>
          </div>
          {isShowEmail && showConfirmModal && alertText && (
            <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
              onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
          )}
        </div>
      )}
      {isShowLoader ? <Loader /> : null}
    </div>
  );
};

export default ForgotPassword;
