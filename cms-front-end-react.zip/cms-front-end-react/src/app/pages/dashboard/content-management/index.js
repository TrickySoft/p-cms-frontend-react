import React from 'react';
import './index.scss';
import Video from './pages/video';
import Banners from './pages/banners';
import FAQ from './pages/faq';
import TermsConditions from './pages/terms-conditions';
import Articles from './pages/articles';
import CodesManuals from './pages/codes&manuals';
import PropTypes from 'prop-types';

const ContentManagement = ({ activeSubTab }) => {
    return (
        <div className='u_width'>
            <div className='u_page'>
                {activeSubTab === 'video' &&
                    <Video />
                }
                {activeSubTab === 'articles' &&
                    <Articles />
                }
                {activeSubTab === 'banners' &&
                    <Banners />
                }
                {activeSubTab === 'faq' &&
                    <FAQ />
                }
                {activeSubTab === 'termsConditions' &&
                    <TermsConditions />
                }
                {
                    activeSubTab === 'codes&manuals' &&
                    <CodesManuals />
                }
            </div>
        </div>
    );
};

ContentManagement.propTypes = {
    activeSubTab: PropTypes.string
};

ContentManagement.defaultProps = {
    activeSubTab: ''
}

export default React.memo(ContentManagement);
