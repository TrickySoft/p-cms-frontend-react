/* eslint-disable no-unused-vars */
import React, { useEffect, useState, useRef } from 'react';
import './index.scss';
import PropTypes from 'prop-types';
import Confirm from '../../../../../components/confirmModal/confirm';
import Loader from '../../../../../components/loader';
import {
  getCodesAndManualsList, updateCodesManuals, uploadCodeFiles, uploadManualFiles,
  deleteCodesManualsFolder, deleteCodesManualsFile
} from '../../../../../utils/apiCalls';
import MultiSelect from 'react-multiselect-checkboxes';
import Button from '../../../../../components/button';
import Name from '../../../../../components/name';
import PopUp from '../../../../../components/popup';
import Arrow from '../../../../../../assets/images/arrow-back-black.svg';

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

//Datatable Modules
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import jsZip from 'jszip';
import 'datatables.net-buttons/js/buttons.html5.min';
import 'datatables.net-buttons/js/buttons.print.min';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
window.JSZip = jsZip;

const CodesManualsDataTable = ({ categoryId, makeId, isViewManuals, handleBackNavigation }) => {
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [columnsList, setColumnsList] = useState();
  const [dataList, setDataList] = useState();
  const [hideTable, setHideTable] = useState(false);
  const [hideColumnList, setHideColumnList] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isShowHideOptions, setIsShowHideOptions] = useState(false);
  const [filteredColumnValues, setFilteredColumnValues] = useState([]);
  const [codesList, setCodesList] = useState([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [codesManualsDetails, setCodesManualsDetails] = useState({});
  const [isUpdateCodesManuals, setIsUpdateCodesManuals] = useState(false);
  const [isActiveCode, setIsActiveCode] = useState(null);
  const [isActiveCodeOption, setIsActiveCodeOption] = useState(0);
  const [isshowCodesDT, setIsshowCodesDT] = useState(false);
  const [isUploadCodesManuals, setIsUploadCodesManuals] = useState(false);
  const [isEmptyData, setIsEmptyData] = useState(false);
  const [dropdownList, setDropdownList] = useState([]);
  const [showdeleteFileConfirmModal, setShowdeleteFileConfirmModal] = useState(false);
  const [showdeleteFolderConfirmModal, setShowdeleteFolderConfirmModal] = useState(false);

  const [isShowModal, setIsShowModal] = useState(false);
  const [actionData, setActionData] = useState([]);
  const menuRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsShowModal(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuRef]);

  const getData = (prevData, page) => {
    setIsEmptyData(false);
    setIsShowLoader(true);
    const payload = {
      limit: 500,
      page: page
    }
    getCodesAndManualsList((response) => {
      const { success, data, message } = response;
      setIsShowLoader(false);
      if (success) {
        let arr = [...prevData, ...data.resultData];
        if (data.currentPage + 1 < data.totalPages) {
          getData(arr, data.currentPage + 1);
        } else {
          let categoryData = arr.filter((manual) => (manual.categoryId === categoryId && manual.makeId === makeId));
          if (categoryData.length) {
            let values = [];
            if (isViewManuals) {
              let manualsFolder = categoryData[0].manualFolder;
              if (manualsFolder.length) {
                setCodesList(manualsFolder);
                values = manualsFolder[0] ? manualsFolder[0].Manuals : [];
                if (values.length) {
                  handleAssignDTValues(values);
                } else {
                  setIsEmptyData(true);
                  setColumnsList([]);
                }
              } else {
                setIsEmptyData(true);
                setCodesList([]);
              }
            } else {
              let codesFolder = categoryData[0].codeFolder;
              if (codesFolder.length) {
                setCodesList(codesFolder);
              } else {
                setIsEmptyData(true);
                setCodesList([]);
              }
              if (isActiveCode !== null) {
                values = codesFolder[isActiveCode] ? codesFolder[isActiveCode].Codes : [];
                if (values.length) {
                  handleAssignDTValues(values);
                }
              }
            }
          } else {
            setIsEmptyData(true);
            setCodesList([]);
          }
        }
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
        setHideTable(false);
      }
    }, payload)
  }

  const handleAssignDTValues = (values) => {
    let columnNames = [];
    var column = [];
    let hideValues = [];
    columnNames = Object.keys(values[0]);
    for (var i in columnNames) {
      column.push({
        data: columnNames[i],
        title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1),
      });
      if (columnNames.length - 1 == i) {
        let obj = {
          title: 'Actions',
          className: 'noExport'
        }
        column.push(obj);
      }
      let obj1 = {};
      obj1 = {
        label: columnNames[i], value: columnNames[i], id: parseInt(i) + 1, checked: true
      }
      hideValues.push(obj1);
      if (columnNames.length - 1 == i) {
        obj1 = {
          label: 'Actions', value: 'Actions', id: parseInt(i) + 2, checked: true
        }
        hideValues.push(obj1);
      }
    }
    setHideTable(true);
    setHideColumnList(hideValues);
    setColumnsList(column);
    setDataList(values);
  }

  useEffect(() => {
    if (hideTable) {
      $(document).ready(function () {
        if ($.fn.dataTable.isDataTable('#data-table')) {
          $('#data-table').DataTable().destroy();
          $('#data-table').empty();
        }
        var table = $('#data-table')
          .DataTable({
            data: dataList,
            columns: columnsList,
            paging: true,
            responsive: true,
            ordering: true,
            dom: 'ifrtlpB',
            buttons: [
              {
                extend: 'collection', text: '', className: 'common-table__export-btn',
                buttons: [
                  {
                    extend: 'csv', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'excel', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'pdf', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  }
                ],
              },
            ],
            columnDefs: [
              {
                data: null,
                sortable: false,
                orderable: false,
                mRender: function (data, type, row, meta) {
                  var itemId = data.id;
                  return '<div class="common-table__dots-parent"><button class="fa fa-ellipsis-v common-table__dots" type="button" data-target="' + meta.row + '"></button><div class="table-menu"  id="' + meta.row + '"><button id="' + itemId + '" type="button" class="table-menu__item">Edit</button><div class="table-menu__divider"></div><button id="' + itemId + '" type="button"  class="table-menu__modal">Delete</button><div class="table-menu__arrow-right"></div></div></div>'
                },
                targets: -1,
              }
            ],
            stateSave: true,
            bRetrieve: true,
            oLanguage: { sProcessing: '<div class="loader" ></div>' },
            'bPaginate': true,
            'bFilter': true,
            'bJQueryUI': true,
            'bLengthChange': true,
            'bStateSave': true,
            'bDeferRender': true,
            'bAutoWidth': false,
            'order': [[1, 'asc']]
          });

        $(window).on('resize', function () {
          table.columns.adjust();
        });

        handleResetColumns(false);
        toggleAllColumns(hideColumnList, true, false);

        $(window).on('click', function () {
          $('.table-menu').hide();
        });

        $('#data-table tbody').on('click', '.common-table__dots', function (e) {
          e.stopPropagation();
          var btnId = $(this).attr('data-target');
          var popUpId = '#' + btnId;
          if ($(popUpId).css('display') == 'none') {
            $('.table-menu').hide();
          }
          if (popUpId) {
            $(popUpId).toggle();
          }
        });

        $('#data-table tbody').on('click', '.table-menu__item', function () {
          var codesmanuals = table.row($(this).parents('tr')).data();
          setCodesManualsDetails(codesmanuals);
          setIsUpdateCodesManuals(true);
        });

        $('#data-table tbody').on('click', '.table-menu__modal', function () {
          var codesmanuals = table.row($(this).parents('tr')).data();
          setCodesManualsDetails(codesmanuals);
          setShowdeleteFileConfirmModal(true);
        });

      });
      setIsShowHideOptions(true);
    } else {
      getData([], 0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataList]);

  const getDropdownButtonLabel = ({ placeholderButtonLabel, value }) => {
    if (value && value.some((o) => o.value === '*')) {
      return `${placeholderButtonLabel}: All`;
    } else {
      const values = [];
      value.map((val, i) => {
        if (i < value.length - 1) {
          values.push(val.value);
          val.checked = false;
        }
      });
      values.splice(0, 0, value[value.length - 1]?.value);
      return `${placeholderButtonLabel}: ${values.join(',')}`;
    }
  };

  const handleResetColumns = (isFromToggleColumns) => {
    if (isFromToggleColumns) {
      $('#data-table').DataTable().columns().visible(true);
      $('#data-table thead tr:eq(1)').remove();
    }
    $('#data-table thead tr').clone(true).appendTo('#data-table thead');
    $('#data-table thead tr:eq(1) th').each(function (i) {
      var title = $(this).text();
      $(this).off('click.DT');
      $(this).removeAttr('aria-controls');
      $(this).removeAttr('aria-sort');
      $(this).removeClass(
        'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
      );
      if (title !== 'Actions') {
        $(this).html(
          '<input type="text" placeholder="Search ' + title + '" />'
        );
        $('input', this).on('keyup change', function () {
          if ($('#data-table').DataTable().column(i).search() !== this.value) {
            $('#data-table').DataTable().column(i).search(this.value).draw();
          }
        });
      }
      else {
        $(this).html(
          <th ></th>
        );
      }
    });
    if (!isFromToggleColumns) {
      $('#data-table thead tr:eq(0) th').each(function (i) {
        if (i === columnsList.length - 1) {
          $(this).removeAttr('aria-controls');
          $(this).removeAttr('aria-sort');
          $(this).removeClass(
            'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
          );
        }
      });
    }
  }

  const toggleAllColumns = (value, isShowColumn, isHideSearch) => {
    if ($.fn.dataTable.isDataTable('#data-table')) {
      handleResetColumns(true);
    }
    let values = [];
    value.map((val) => {
      val.checked = false;
      var valId = val.id - 1;
      if (val.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
        values.push(val);
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
    if (values?.length !== 0) {
      setFilteredColumnValues(values);
      setSelectedOptions([
        { label: 'All', value: '*' },
        ...values,
      ]);
    }
  };

  const toggleColumn = (value, isShowColumn, isHideSearch) => {
    var valId = value.id - 1;
    $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
    $('#data-table thead tr:eq(1) th').each(function () {
      if (value.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
  };

  const onChange = (value, event) => {
    if (event.action === 'select-option' && event.option.value === '*') {
      toggleAllColumns(hideColumnList, true, false);
      setSelectedOptions([{ label: 'All', value: '*' }, ...filteredColumnValues]);
    } else if (
      event.action === 'deselect-option' &&
      event.option.value === '*'
    ) {
      toggleAllColumns(hideColumnList, false, true);
      setSelectedOptions([]);
    } else if (event.action === 'deselect-option') {
      toggleColumn(event.option, false, true);
      setSelectedOptions(value.filter((o) => o.value !== '*'));
    } else {
      toggleColumn(event.option, true, false);
      if (filteredColumnValues.length === value.length) {
        setSelectedOptions([{ label: 'All', value: '*' }, ...value]);
      } else {
        setSelectedOptions(value);
      }
    }
  };

  const handleUploadConfirm = (id, obj) => {
    setIsShowLoader(true);
    const formData = new FormData();
    for (var file of obj.file.file) {
      formData.append('file', file);
    }
    formData.append('makeId', makeId);
    formData.append('categoryId', categoryId);
    if (!isViewManuals) {
      formData.append('title', obj.selectedDropdown1Value);
      uploadCodeFiles((response) => {
        const { success, data, message } = response;
        setIsShowLoader(false);
        if (success) {
          getData([], 0);
          setIsUploadCodesManuals(false);
        } else {
          setAlertText(message);
          setShowConfirmModal(true);
        }
      }, formData)
    } else {
      uploadManualFiles((response) => {
        const { success, data, message } = response;
        setIsShowLoader(false);
        if (success) {
          getData([], 0);
          setIsUploadCodesManuals(false);
        } else {
          setAlertText(message);
          setShowConfirmModal(true);
        }
      }, formData)
    }

  }

  const handleConfirm = (id, obj) => {
    setIsShowLoader(true);
    const payload = {
      id: codesManualsDetails.id,
      title: obj.text1,
      description: obj.desc1Value,
      tag: obj.text2,
    }
    if (isViewManuals) {
      payload.isManual = true;
      payload.manualsImage = obj.file.image;
      handleUpload(payload);
    } else {
      payload.isManual = false;
      handleUpload(payload);
    }
  }

  const handleUpload = (payload) => {
    updateCodesManuals((response) => {
      const { success, data, message } = response;
      setIsShowLoader(false);
      if (success) {
        getData([], 0);
        setIsUpdateCodesManuals(false);
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
      }
    }, payload)
  }

  const handleCodes = (i, code) => {
    setIsActiveCode(i);
    if (i === isActiveCode) {
      setHideTable(true);
      setDataList([]);
      setIsshowCodesDT(!isshowCodesDT);
      if (!isshowCodesDT && code.Codes.length) {
        handleAssignDTValues(code.Codes);
      }
    } else {
      if (code.Codes.length) {
        handleAssignDTValues(code.Codes);
        setIsshowCodesDT(true);
      }
    }
  }

  const handleUploadFiles = () => {
    if (!isViewManuals) {
      let list = [];
      codesList.map((code) => {
        list.push({
          'name': code.title,
          'value': code.title
        })
      });
      setDropdownList(list);
    }
    setIsUploadCodesManuals(true);
  }

  const handleDeleteCodesManualsFile = () => {
    setShowdeleteFileConfirmModal(false);
    setIsShowLoader(true);
    const payload = {
      'folderId': codesManualsDetails.id
    }
    if (isViewManuals) {
      payload.isManual = true;
    } else {
      payload.isManual = false;
    }
    deleteCodesManualsFile((response) => {
      const { success, message } = response;
      if (success) {
        getData([], 0);
        setCodesManualsDetails({});
      }
      setAlertText(message);
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  };

  const handleDeleteCodesManualsFolder = () => {
    setShowdeleteFolderConfirmModal(false);
    setIsShowLoader(true);
    let payload;
    if (isViewManuals) {
      let id = codesList[0].id;
      payload = {
        'folderId': id,
        isManual: true
      }
    } else {
      payload = {
        'folderId': actionData.id,
        isManual: false
      }
    }
    deleteCodesManualsFolder((response) => {
      const { success, message } = response;
      if (success) {
        getData([], 0);
        setCodesManualsDetails({});
      }
      setAlertText(message);
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  };

  return (
    <div >
      <div className='pageHeader'>
        <Name tabTitle='Content-Management' title={isViewManuals ? 'Manuals' : 'Codes'} />
        <div className={isViewManuals ? 'u_flex code-manual__width35' : 'u_flex'}>
          <Button buttonId={isViewManuals ? 'UploadManuals' : 'UploadCodes'}
            className='pageHeader__button'
            buttonClick={handleUploadFiles} >
            {isViewManuals ? 'Upload Manuals' : 'Upload Codes'}
          </Button>
          {isViewManuals &&
            <Button buttonId='deleteManuals' isBtnDisabled={codesList.length === 0 ? true : false}
              className='pageHeader__button delete-btn'
              buttonClick={() => setShowdeleteFolderConfirmModal(true)} >
              Delete Manuals
            </Button>
          }
        </div>
      </div>
      <div className='cursor_pointer code-manual__back-arrow' onClick={handleBackNavigation}> <img src={Arrow} alt='arrow' /> Go Back</div>
      {isViewManuals ?
        ((codesList && codesList.length && columnsList?.length > 0) ?
          <div className='common-table'>
            {isShowHideOptions &&
              <div className='common-table__toggle'>
                <MultiSelect
                  options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
                  placeholderButtonLabel='Show '
                  getDropdownButtonLabel={getDropdownButtonLabel}
                  value={selectedOptions}
                  onChange={onChange}
                  setState={setSelectedOptions}
                  hideSearch={true}
                />
              </div>
            }
            <table id='data-table' className='display' width='100%'></table>
          </div>
          : null
        )
        :
        <div className='code-manual__margin title-bdr'>
          {
            (codesList && codesList.length) ?
              codesList.map((code, i) => {
                return (
                  < div key={i}>
                    <div className={(isshowCodesDT && i === isActiveCode) ?
                      'code-manual__title code-manual__active code-manual__bdr-width' : 'code-manual__title code-manual__bdr '}
                    >
                      <div className='code-manual__btn' onClick={() => handleCodes(i, code)}>
                        <div className='code-manual__arrow-box'>
                          {(isshowCodesDT && i === isActiveCode) ?
                            <span className='code-manual__arrow code-manual__down-arrow'></span>
                            :
                            <span className='code-manual__arrow code-manual__right-arrow'></span>
                          }
                        </div>
                        <span>{code.title}</span>
                      </div>
                      <i className='fa fa-ellipsis-v code-manual__dots' onClick={() => { setIsActiveCodeOption(i); setIsShowModal(true) }}>
                        {isShowModal && i === isActiveCodeOption ?
                          <div className='code-manual__modal' ref={menuRef}>
                            <div className='code-manual__items' onClick={() => { setActionData(code); setShowdeleteFolderConfirmModal(true) }}> Delete Folder </div>
                          </div>
                          :
                          null
                        }
                        {isShowModal && i === isActiveCodeOption ?
                          <div className='code-manual__arrow-right'></div>
                          :
                          null
                        }
                      </i>
                    </div>
                    {(i === isActiveCode && isshowCodesDT && (code.Codes.length > 0)) ?
                      <div className='common-table'>
                        {isShowHideOptions &&
                          <div className='common-table__toggle'>
                            <MultiSelect
                              options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
                              placeholderButtonLabel='Show '
                              getDropdownButtonLabel={getDropdownButtonLabel}
                              value={selectedOptions}
                              onChange={onChange}
                              setState={setSelectedOptions}
                              hideSearch={true}
                            />
                          </div>
                        }
                        <table id='data-table' className='display' width='100%'></table>
                      </div> : null
                    }
                    {(isshowCodesDT && i === isActiveCode && code.Codes.length === 0) &&
                      <div className='code-manual__title code-manual__bdr-top code-manual__justify-text'> {isViewManuals ? 'Manuals' : 'Codes'} are not available ! </div>
                    }
                  </div>
                )
              })
              : null
          }
        </div>
      }
      {isUpdateCodesManuals &&
        <PopUp id={isViewManuals ? 'updateManualModal' : 'updateCodeModal'}
          onConfirm={handleConfirm} onCancel={() => { setIsUpdateCodesManuals(false) }} commonTitle={isViewManuals ? 'Edit Manuals' : 'Edit Codes'}
          isInput1Required={false} input1Placeholder='Title' isShowInput1={true} input1Value={codesManualsDetails.title}
          isInput2Required={false} isShowInput2={true} input2Value={codesManualsDetails.tag} input2Placeholder='Tag' input5Placeholder='Upload file'
          isDescription1Required={false} isShowDescription1={true} desc1TextValue={codesManualsDetails.description} desc1Placeholder='Description'
          isShowInput6={isViewManuals ? true : false} updateFile={isViewManuals ? codesManualsDetails.manualsImage : undefined}
          btnText='DONE' />
      }
      {showConfirmModal && (
        <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
          onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
      )}
      {isShowLoader ? <Loader /> : null}
      {isUploadCodesManuals &&
        <PopUp id={isViewManuals ? 'uploadManualModal' : 'uploadCodeModal'}
          onConfirm={handleUploadConfirm} onCancel={() => { setIsUploadCodesManuals(false); }} commonTitle='Add New Article'
          input5Placeholder='Upload multiple files' isShowInput5={true} isMultiple={true} acceptFileType='application/pdf' isDropdown1Visible={true}
          dropdown1Placeholder='Search or Add Title' isSearchDropdown={!isViewManuals ? true : false} dropdown1List={!isViewManuals ? dropdownList : []}
          btnText='DONE' />}
      {isEmptyData &&
        <div className='u_emptyData'> {isViewManuals ? 'Manuals' : 'Codes'} are not available ! </div>
      }
      {
        showdeleteFileConfirmModal && (
          <Confirm buttonText={'OK'} isCancelRequired={true} confirmTitle='Are you sure you want to Delete the File?'
            onConfirm={handleDeleteCodesManualsFile} onCancel={() => { setShowdeleteFileConfirmModal(false) }} />
        )
      }
      {
        showdeleteFolderConfirmModal && (
          <Confirm buttonText={'OK'} isCancelRequired={true} confirmTitle='Are you sure you want to Delete the Folder?'
            onConfirm={handleDeleteCodesManualsFolder} onCancel={() => { setShowdeleteFolderConfirmModal(false) }} />
        )
      }
    </div>
  )
}

CodesManualsDataTable.propTypes = {
  makeId: PropTypes.string,
  categoryId: PropTypes.string,
  isViewManuals: PropTypes.bool,
  handleBackNavigation: PropTypes.func
}

CodesManualsDataTable.defaultProps = {
  makeId: '',
  categoryId: '',
  isViewManuals: false,
  handleBackNavigation: () => { }
}

export default React.memo(CodesManualsDataTable);

