/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import Name from '../../../../../components/name';
import Button from '../../../../../components/button/index';
import PopUp from '../../../../../components/popup/index';
import Confirm from '../../../../../components/confirmModal/confirm';
import { getBannerList, createBanner, deleteBanner, updateBanner, getPageList } from '../../../../../utils/apiCalls';
import MultiSelect from 'react-multiselect-checkboxes';
import Loader from '../../../../../components/loader';
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import './index.scss';

//Datatable Modules
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import jsZip from 'jszip';
import 'datatables.net-buttons/js/buttons.html5.min';
import 'datatables.net-buttons/js/buttons.print.min';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
window.JSZip = jsZip;

const Banners = () => {
  const [isShowBanner, setIsShowBanner] = useState(false);
  const [isEditBanner, setIsEditBanner] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [columnsList, setColumnsList] = useState();
  const [dataList, setDataList] = useState();
  const [hideTable, setHideTable] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [bannerId, setBannerId] = useState('');
  const [bannerHideList, setBannerHideList] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isShowHideOptions, setIsShowHideOptions] = useState(false);
  const [filteredColumnValues, setFilteredColumnValues] = useState([]);
  const [bannerDetails, setBannerDetails] = useState({});
  const [dropdownList, setDropdownList] = useState([]);

  const getData = () => {
    setIsShowLoader(true);
    getBannerList((response) => {
      const { success, message, data } = response;
      setIsShowLoader(false);
      if (success && data?.data?.length) {
        var values = data.data;
        let columnNames = [];
        var column = [];
        let hideValues = [];
        columnNames = Object.keys(values[0]);
        values.forEach((val) => {
          if (val.Page) {
            val.Page = val.Page.name;
          }
        });
        for (var i in columnNames) {
          column.push({
            data: columnNames[i],
            title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1)
          });
          if (columnNames.length - 1 == i) {
            let obj = {
              title: 'Actions',
              className: 'noExport'
            }
            column.push(obj);
          }
          let obj1 = {};
          obj1 = {
            label: columnNames[i], value: columnNames[i], id: parseInt(i) + 1, checked: true
          }
          hideValues.push(obj1);
          if (columnNames.length - 1 == i) {
            obj1 = {
              label: 'Actions', value: 'Actions', id: parseInt(i) + 2, checked: true
            }
            hideValues.push(obj1);
          }
        }
        setHideTable(true);
        setBannerHideList(hideValues);
        setColumnsList(column);
        setDataList(values);
      } else if (!success) {
        setAlertText(message);
        setShowConfirmModal(true);
        setHideTable(false);
      }
    });

  };

  const getPageData = () => {
    getPageList((response) => {
      const { success, message, data } = response;
      if (success) {
        let list = [];
        data.map((data) => {
          list.push({
            'name': data.name,
            'value': data.name,
            'id': data.id
          })
        });
        setDropdownList(list);
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
      }
    })
  }

  useEffect(() => {
    if (hideTable) {
      $(document).ready(function () {
        if ($.fn.dataTable.isDataTable('#data-table')) {
          $('#data-table').DataTable().destroy();
          $('#data-table').empty();
        }
        var table = $('#data-table')
          .DataTable({
            data: dataList,
            columns: columnsList,
            paging: true,
            responsive: true,
            ordering: true,
            dom: 'ifrtlpB',
            buttons: [
              {
                extend: 'collection', text: '', className: 'common-table__export-btn',
                buttons: [
                  {
                    extend: 'csv', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'excel', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'pdf', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  }
                ],
              },
            ],
            columnDefs: [
              {
                data: null,
                sortable: false,
                orderable: false,
                mRender: function (data, type, row, meta) {
                  return '<div class="common-table__dots-parent"><button class="fa fa-ellipsis-v common-table__dots" type="button" data-target="' + meta.row + '"></button><div class="table-menu"  id="' + meta.row + '"><button id="' + data.id + '" type="button" class="table-menu__modal">Edit</button><div class="table-menu__divider"></div><button id="' + data.id + '" type="button" class="table-menu__item">Delete</button><div class="table-menu__arrow-right"></div></div></div>'
                },
                targets: [-1],
              }
            ],
            stateSave: true,
            bRetrieve: true,
            oLanguage: { sProcessing: '<div class="loader" ></div>' },
            'bPaginate': true,
            // 'sPaginationType': 'full_numbers',
            'bFilter': true,
            'bJQueryUI': true,
            'bLengthChange': true,
            'bStateSave': true,
            'bDeferRender': true,
            'bAutoWidth': true,
            order: [[1, 'asc']]
          });

        $(window).on('click', function (e) {
          $('.table-menu').hide();
        });

        $('#data-table tbody').on('click', '.common-table__dots', function (e) {
          e.stopPropagation();
          var btnId = $(this).attr('data-target');
          var popUpId = '#' + btnId;
          if ($(popUpId).css('display') == 'none') {
            $('.table-menu').hide();
          }
          if (popUpId) {
            $(popUpId).toggle();
          }
        });

        $('#data-table tbody').on('click', '.table-menu__item', function (e) {
          var id = $(this).attr('id');
          setBannerId(id);
          setShowDeleteConfirmModal(true);
        });

        $('#data-table tbody').on('click', '.table-menu__modal', function (e) {
          let banner = table.row($(this).parents('tr')).data();
          setBannerDetails(banner);
          setIsEditBanner(true);
        });

        handleResetColumns(false);
        toggleAllColumns(bannerHideList, true, false);
      });
      setIsShowHideOptions(true);
    } else {
      getData();
      getPageData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataList]);

  const handleBannerModal = (id, obj) => {
    setIsShowLoader(true);
    const payload = {
      'bannerImage': obj.file.image,
      'title': obj.text1,
      'bannerOrder': obj.text2,
      'page': obj.selectedDropdown1Value.id,
      'note': obj.desc1Value
    }
    if (obj.selectedDropdown1Value.name === 'webpage') {
      payload.url = obj.pageUrl
    }
    if (id === 'addBanner') {
      createBanner((response) => {
        const { success, message } = response;
        setIsShowLoader(false);
        if (success) {
          getData();
        }
        setAlertText(message);
        setShowConfirmModal(true);
      }, payload)
      setIsShowBanner(false);
    } else if (id === 'editBanner') {
      payload.id = bannerDetails.id;
      updateBanner((response) => {
        const { success, message } = response;
        setIsShowLoader(false);
        if (success === true) {
          getData();
          setAlertText('Banner updated successfully !');
        } else {
          setAlertText(message);
        }
        setShowConfirmModal(true);
      }, payload)
    }
    setIsEditBanner(false);
  };

  const handleRemoveBannerModal = () => {
    setShowDeleteConfirmModal(false);
    setIsShowLoader(true);
    if (bannerId) {
      let payload = {
        bannerId: bannerId
      }
      deleteBanner((response) => {
        const { success, message } = response;
        setIsShowLoader(false);
        if (success) {
          getData();
        }
        setAlertText(message);
        setShowConfirmModal(true);
      }, payload);
    }
  }

  const getDropdownButtonLabel = ({ placeholderButtonLabel, value }) => {
    if (value && value.some((o) => o.value === '*')) {
      return `${placeholderButtonLabel}: All`;
    } else {
      const values = [];
      value.map((val, i) => {
        if (i < value.length - 1) {
          values.push(val.value);
          val.checked = false;
        }
      });
      values.splice(0, 0, value[value.length - 1]?.value);
      return `${placeholderButtonLabel}: ${values.join(',')}`;
    }
  };

  const handleResetColumns = (isFromToggleColumns) => {
    if (isFromToggleColumns) {
      $('#data-table').DataTable().columns().visible(true);
      $('#data-table thead tr:eq(1)').remove();
    }
    $('#data-table thead tr').clone(true).appendTo('#data-table thead');
    $('#data-table thead tr:eq(1) th').each(function (i) {
      var title = $(this).text();
      $(this).off('click.DT');
      $(this).removeAttr('aria-controls');
      $(this).removeAttr('aria-sort');
      $(this).removeClass(
        'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
      );
      if (title !== 'Actions') {
        $(this).html(
          '<input type="text" placeholder="Search ' + title + '" />'
        );
        $('input', this).on('keyup change', function () {
          if ($('#data-table').DataTable().column(i).search() !== this.value) {
            $('#data-table').DataTable().column(i).search(this.value).draw();
          }
        });
      }
      else {
        $(this).html(
          <th ></th>
        );
      }
    });
    if (!isFromToggleColumns) {
      $('#data-table thead tr:eq(0) th').each(function (i) {
        if (i === columnsList.length - 1) {
          $(this).removeAttr('aria-controls');
          $(this).removeAttr('aria-sort');
          $(this).removeClass(
            'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
          );
        }
      });
    }
  }

  const toggleAllColumns = (value, isShowColumn, isHideSearch) => {
    if ($.fn.dataTable.isDataTable('#data-table')) {
      handleResetColumns(true);
    }
    let values = [];
    value.map((val) => {
      val.checked = false;
      var valId = val.id - 1;
      if (val.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
        values.push(val);
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
    if (values?.length !== 0) {
      setFilteredColumnValues(values);
      setSelectedOptions([
        { label: 'All', value: '*' },
        ...values,
      ]);
    }
  };

  const toggleColumn = (value, isShowColumn, isHideSearch) => {
    var valId = value.id - 1;
    $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
    $('#data-table thead tr:eq(1) th').each(function () {
      if (value.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
  };

  const onChange = (value, event) => {
    if (event.action === 'select-option' && event.option.value === '*') {
      toggleAllColumns(bannerHideList, true, false);
      setSelectedOptions([{ label: 'All', value: '*' }, ...filteredColumnValues]);
    } else if (
      event.action === 'deselect-option' &&
      event.option.value === '*'
    ) {
      toggleAllColumns(bannerHideList, false, true);
      setSelectedOptions([]);
    } else if (event.action === 'deselect-option') {
      toggleColumn(event.option, false, true);
      setSelectedOptions(value.filter((o) => o.value !== '*'));
    } else {
      toggleColumn(event.option, true, false);
      if (filteredColumnValues.length === value.length) {
        setSelectedOptions([{ label: 'All', value: '*' }, ...value]);
      } else {
        setSelectedOptions(value);
      }
    }
  };

  return (
    <div>
      <div className='pageHeader'>
        <Name tabTitle='Content-Management' title='Banners' />
        <div >
          <Button
            className='pageHeader__button'
            buttonClick={() => {
              setIsShowBanner(true);
            }}
          >
            Add New Banner
          </Button>
        </div>
        {
          showDeleteConfirmModal && (
            <Confirm buttonText={'OK'} confirmTitle={'Are you sure want to delete the Banner ?'} isCancelRequired={true}
              onConfirm={handleRemoveBannerModal} onCancel={() => { setShowDeleteConfirmModal(false) }} />
          )
        }
        {
          showConfirmModal && (
            <Confirm buttonText={'OK'} confirmTitle={alertText} isCancelRequired={false}
              onConfirm={() => setShowConfirmModal(false)} onCancel={() => { setShowConfirmModal(false) }} />
          )
        }
        {isShowBanner ? (
          <PopUp
            id='addBanner'
            onCancel={() => setIsShowBanner(false)}
            commonTitle='Add New Banner'
            isShowDescription1={true}
            isShowInput1={true}
            isShowInput2={true}
            dropdown1Placeholder='Page'
            isDropdown1Required={true}
            dropdown1List={dropdownList}
            input1Placeholder='Title'
            input2Placeholder='BannerOrder'
            desc1Placeholder='Note'
            isShowImage={true}
            onConfirm={handleBannerModal}
            btnText='DONE'
          />
        ) : (
          null
        )}
        {isEditBanner ? (
          <PopUp
            id='editBanner'
            onCancel={() => setIsEditBanner(false)}
            commonTitle='Edit Banner'
            isShowDescription1={true}
            isShowInput1={true}
            isShowInput2={true}
            dropdown1Placeholder='Page'
            isDropdown1Required={true}
            input1Value={bannerDetails.title}
            input2Value={bannerDetails.bannerOrder}
            desc1TextValue={bannerDetails.note}
            input1Placeholder='Title'
            input2Placeholder='BannerOrder'
            dropdown1List={dropdownList}
            desc1Placeholder='Note'
            isShowImage={true}
            onConfirm={handleBannerModal}
            btnText='DONE'
            updateFile={bannerDetails.bannerImage}
            updateUrl={bannerDetails.url}
            updateSelectedDropDown1Value={bannerDetails.Page}
          />
        ) : (
          null
        )}
      </div>
      <div className='common-table'>
        {isShowHideOptions &&
          <div className='common-table__toggle'>
            <MultiSelect
              options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
              placeholderButtonLabel='Show '
              getDropdownButtonLabel={getDropdownButtonLabel}
              value={selectedOptions}
              onChange={onChange}
              setState={setSelectedOptions}
              hideSearch={true}
            />
          </div>
        }
        <table id='data-table' className='display' width='100%'></table>
      </div>
      {isShowLoader && <Loader />}
    </div>
  );
}

Banners.propTypes = {
};

Banners.defaultProps = {
}

export default React.memo(Banners);
