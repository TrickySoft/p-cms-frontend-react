/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import './index.scss';
import Name from '../../../../../components/name';
import { getMachineCategoryMakeWiseList, createMachineCategory } from '../../../../../utils/apiCalls';
import PopUp from '../../../../../components/popup';
import Button from '../../../../../components/button';
import Confirm from '../../../../../components/confirmModal/confirm';
import Loader from '../../../../../components/loader';
import CodesManualsDataTable from './codesmanuals';

const CodesAndManuals = () => {
  const [machines, setMachines] = useState([]);
  const [isActiveMake, setIsActiveMake] = useState(0);
  const [isActiveCategory, setIsActiveCategory] = useState(0);
  const [isshowCategories, setIsshowCategories] = useState(false);
  const [isshowModels, setIsshowModels] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [isViewCodesManuals, setIsViewCodesManuals] = useState(false);
  const [isViewManuals, setIsViewManuals] = useState(false);
  const [categorymakeId, setCategorymakeId] = useState({});
  const [isAddCategory, setIsAddCategory] = useState(false);
  const [dropdownList, setDropdownList] = useState([]);

  useEffect(() => {
    getData();
  }, []);

  const getData = () => {
    setIsShowLoader(true);
    getMachineCategoryMakeWiseList((response) => {
      const { success, data, message } = response;
      setIsShowLoader(false);
      if (success) {
        setMachines(data);
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
      }
    })
  }

  const handleCategories = (i) => {
    setIsActiveMake(i);
    if (i === isActiveMake) {
      setIsshowCategories(!isshowCategories);
    } else {
      setIsshowCategories(true);
      setIsshowModels(false);
    }
    if (!isshowCategories) {
      setIsshowModels(false);
    }
  }

  const handleModels = (j) => {
    setIsActiveCategory(j);
    if (j === isActiveCategory) {
      setIsshowModels(!isshowModels);
    } else {
      setIsshowModels(true);
    }
  }

  const handleViewManuals = (category, make) => {
    setIsViewManuals(true);
    setCategorymakeId({
      categoryId: category.id,
      makeId: make.makeId
    });
    setIsViewCodesManuals(true);
  }

  const handleViewCodes = (category, make) => {
    setCategorymakeId({
      categoryId: category.id,
      makeId: make.makeId
    });
    setIsViewCodesManuals(true);
  }

  const handleShowCodesManuals = () => {
    setIsViewManuals(false);
    setCategorymakeId('');
    setIsViewCodesManuals(false);
  }

  const handleAddCategory = () => {
    let list = [];
    machines.map((machine) => {
      list.push({
        'name': machine.make,
        'value': machine.make
      })
    });
    setDropdownList(list);
    setIsAddCategory(true);
  }

  const handleOnsubmit = (id, obj) => {
    setIsShowLoader(true);
    const payload = {
      'make': obj.selectedDropdown1Value,
      'category': obj.text1,
      'categoryImage': obj.file.image,
      'note': obj.desc1Value,
    }
    createMachineCategory((response) => {
      const { success, message } = response;
      if (success) {
        getData();
        setIsAddCategory(false);
        setAlertText('Successfully added the Category !');
      } else {
        setAlertText(message);
      }
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  }

  return (
    <div>
      {!isViewCodesManuals ?
        <div>
          <div className='code-manual__hdr'>
            <Name title={'Codes & Manuals'} />
            <div className='code-manual__header__popup'>
              <Button className='code-manual__button code-manual__pad16' buttonClick={() => { handleAddCategory() }} >
                Add Category
              </Button>
              {isAddCategory ?
                <PopUp id='addCategoryModal' onCancel={() => { setIsAddCategory(false) }} commonTitle='Add Category' dropdown1List={dropdownList}
                  isShowInput1={true} isShowInput6={true} isShowDescription1={true} input1Placeholder='Category Name'
                  desc1Placeholder='Note' dropdown1Placeholder='Search or Add Make' isSearchDropdown={true}
                  onConfirm={handleOnsubmit} btnText='DONE' />
                :
                null
              }
            </div>
          </div>
          {machines && machines.length ?
            <div className='code-manual'>
              <div className='code-manual__header'>
                MAKE :
              </div>
              {machines.map((machine, i) => {
                return (
                  < div key={i}>
                    <div className={(isshowCategories && i === isActiveMake) ? 'code-manual__title code-manual__active code-manual__bdr-bottom' : 'code-manual__title'}
                      onClick={() => handleCategories(i)}>
                      <div className='code-manual__btn'>
                        <div className='code-manual__arrow-box'>
                          {(isshowCategories && i === isActiveMake) ?
                            <span className='code-manual__arrow code-manual__down-arrow'></span>
                            :
                            <span className='code-manual__arrow code-manual__right-arrow'></span>
                          }
                        </div>
                        <span>{machine.make}</span>
                      </div>
                    </div>
                    {i === isActiveMake && isshowCategories ?
                      <div>
                        <div className='code-manual__header code-manual__pad1'>
                          <span>CATEGORIES :</span>
                        </div>
                        {machine.category && machine.category.length ?
                          machine.category.map((category, j) => {
                            return (
                              <div key={j}>
                                <div className={isshowModels && isActiveCategory === j ?
                                  'code-manual__title code-manual__pad2 code-manual__active code-manual__bdr-bottom' : 'code-manual__title code-manual__pad2'}>
                                  <div className='code-manual__btn' onClick={() => handleModels(j)}>
                                    <div className='code-manual__arrow-box'>
                                      {(isshowModels && isActiveCategory === j) ?
                                        <span className='code-manual__arrow code-manual__down-arrow'></span>
                                        :
                                        <span className='code-manual__arrow code-manual__right-arrow'></span>
                                      }
                                    </div>
                                    <span>{category.name}</span>
                                  </div>
                                </div>
                                {
                                  j === isActiveCategory && isshowModels ?
                                    <div>
                                      <div className='code-manual__bdr-bottom'>
                                        <div className='code-manual__header code-manual__pad3'>
                                          <span> Manuals : </span>
                                          <div className='code-manual__btn-width'>
                                            <Button className='code-manual__button' buttonClick={() => { handleViewManuals(category, machine) }} >
                                              View Manuals
                                            </Button>
                                          </div>
                                        </div>
                                      </div>

                                      <div className='codes'>
                                        <div className='code-manual__header code-manual__pad3'>
                                          <span> Codes : </span>
                                          <div className='code-manual__btn-width'>
                                            <Button className='code-manual__button' buttonClick={() => { handleViewCodes(category, machine) }} >
                                              View Codes
                                            </Button>
                                          </div>
                                        </div>
                                      </div>

                                    </div>
                                    : null
                                }
                              </div>

                            )
                          })
                          :
                          <div className='code-manual__title code-manual__justify-text'> Categories are not available ! </div>
                        }
                      </div>
                      : null
                    }
                  </div>
                )
              })
              }
            </div>
            : null
          }
          {showConfirmModal && (
            <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
              onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
          )}
          {isShowLoader ? <Loader /> : null}
        </div>
        :
        <div>
          {
            isViewManuals ?
              <CodesManualsDataTable categoryId={categorymakeId.categoryId} makeId={categorymakeId.makeId} isViewManuals={true} handleBackNavigation={() => handleShowCodesManuals()} />
              :
              <CodesManualsDataTable categoryId={categorymakeId.categoryId} makeId={categorymakeId.makeId} handleBackNavigation={() => handleShowCodesManuals()} />
          }
        </div>
      }
    </div>
  )
}

CodesAndManuals.propTypes = {
};

CodesAndManuals.defaultProps = {

}

export default React.memo(CodesAndManuals);
