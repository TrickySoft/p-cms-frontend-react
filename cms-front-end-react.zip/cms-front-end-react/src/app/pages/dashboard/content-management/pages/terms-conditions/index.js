import React, { useState, useEffect } from 'react';
import Name from '../../../../../components/name';
import Button from '../../../../../components/button/index';
import PopUp from '../../../../../components/popup/index';
import { getTermsAndCondition, updateTermsAndCondition } from '../../../../../utils/apiCalls';
import Confirm from '../../../../../components/confirmModal/confirm';
import Loader from '../../../../../components/loader';
import './index.scss';

const TermsConditions = () => {
  const [isShowTerms, setIsShowTerms] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [dataList, setDataList] = useState();
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);

  const getData = () => {
    setIsShowLoader(true);
    getTermsAndCondition((response) => {
      const { success, message, data } = response;
      setIsShowLoader(false);
      if (success) {
        setDataList(data);
      } else if (!success) {
        setAlertText(message);
        setShowConfirmModal(true);
      }
    });
  };

  useEffect(() => {
    getData();
  }, [])

  const handleTermsModal = (id, obj) => {
    setIsShowTerms(false);
    const formData = new FormData();
    formData.append('file', obj.file.file);
    updateTermsAndCondition((response) => {
      const { success } = response;
      if (success) {
        getData();
      }
      setAlertText('Successfully updated the Terms & Conditions !');
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, formData);
  };

  return (
    <div>
      <Name tabTitle='Content-Management' title={'Terms & Conditions'} />

      {isShowTerms &&
        <PopUp
          id='editTerms'
          onCancel={() => setIsShowTerms(false)}
          commonTitle='Edit Terms & Conditions'
          isShowInput5={true}
          acceptFileType='.html'
          input5Placeholder='Select File'
          onConfirm={handleTermsModal}
          btnText='DONE'
        />
      }
      {
        showConfirmModal && (
          <Confirm buttonText={'OK'} confirmTitle={alertText} isCancelRequired={false}
            onConfirm={() => setShowConfirmModal(false)} onCancel={() => { setShowConfirmModal(false) }} />
        )
      }
      <div className='conditions'>
        <iframe src={dataList?.termsAgreementLink} className='conditions__iframe' frameBorder='0' title='Terms & Conditions'></iframe>
        <div className='conditions__version'>
          termsAgreementVersion - {dataList?.termsAgreementVersion}
        </div>
        <div className='conditions__button'>
          <Button
            className='pageHeader__button conditions__button__width20'
            buttonClick={() => {
              setIsShowTerms(true);
            }}
          >
            Update T&C
          </Button>
        </div>
      </div>
      {isShowLoader && <Loader />}
    </div>
  )
}

TermsConditions.propTypes = {
};

TermsConditions.defaultProps = {
}

export default React.memo(TermsConditions);
