import React, { useEffect, useState } from 'react';
import Name from '../../../../../components/name';
import MultiSelect from 'react-multiselect-checkboxes';
import Confirm from '../../../../../components/confirmModal/confirm';
import './index.scss';
import { getArticleList, createArticle, updateArticle, deleteArticle, uploadImageFile } from '../../../../../utils/apiCalls';
import PopUp from '../../../../../components/popup';
import Button from '../../../../../components/button/index';
import Loader from '../../../../../components/loader';

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

//Datatable Modules
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import jsZip from 'jszip';
import 'datatables.net-buttons/js/buttons.html5.min';
import 'datatables.net-buttons/js/buttons.print.min';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
window.JSZip = jsZip;

const Articles = () => {
  const [isAddArticle, setIsAddArticle] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [articleDetails, setArticleDetails] = useState('');
  const [columnsList, setColumnsList] = useState();
  const [dataList, setDataList] = useState();
  const [hideTable, setHideTable] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isUpdateArticle, setIsUpdateArticle] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [showdeleteConfirmModal, setShowdeleteConfirmModal] = useState(false);
  const [hideColumnList, setHideColumnList] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isShowHideOptions, setIsShowHideOptions] = useState(false);
  const [filteredColumnValues, setFilteredColumnValues] = useState([]);

  const getData = (prevData, page) => {
    setIsShowLoader(true);
    let payload = {
      limit: 500,
      page: page
    }
    getArticleList((response) => {
      const { success, message, data } = response;
      setIsShowLoader(false);
      if (success && data?.data?.length) {
        let arr = [...prevData, ...data.data];
        if (data.currentPage + 1 < data.totalPages) {
          getData(arr, data.currentPage + 1);
        }else{
          var values = data.data;
          let columnNames = [];
          var column = [];
          let hideValues = [];
          columnNames = Object.keys(values[0]);
          for (var i in columnNames) {
            if (columnNames[i] === 'description') {
              column.push({
                data: columnNames[i],
                title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1),
                render: function (value) {
                  if (value.length > 40) {
                    value = value.substring(0, 40) + '...';
                  }
                  return value;
                }
              });
            } else {
              column.push({
                data: columnNames[i],
                title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1),
              });
            }
            if (columnNames.length - 1 == i) {
              let obj = {
                title: 'Actions',
                className: 'noExport'
              }
              column.push(obj);
            }
            let obj1 = {};
            obj1 = {
              label: columnNames[i], value: columnNames[i], id: parseInt(i) + 1, checked: true
            }
            hideValues.push(obj1);
            if (columnNames.length - 1 == i) {
              obj1 = {
                label: 'Actions', value: 'Actions', id: parseInt(i) + 2, checked: true
              }
              hideValues.push(obj1);
            }
          }
          setHideTable(true);
          setHideColumnList(hideValues);
          setColumnsList(column);
          setDataList(values);
        }
      
      } else if (!success) {
        setAlertText(message);
        setShowConfirmModal(true);
        setHideTable(false);
      }
    }, payload);
  };

  useEffect(() => {
    if (hideTable) {
      $(document).ready(function () {
        if ($.fn.dataTable.isDataTable('#data-table')) {
          $('#data-table').DataTable().destroy();
          $('#data-table').empty();
        }
        var table = $('#data-table')
          .DataTable({
            data: dataList,
            columns: columnsList,
            paging: true,
            responsive: true,
            ordering: true,
            dom: 'ifrtlpB',
            buttons: [
              {
                extend: 'collection', text: '', className: 'common-table__export-btn',
                buttons: [
                  {
                    extend: 'csv', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'excel', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'pdf', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  }
                ],
              },
            ],
            columnDefs: [
              {
                data: null,
                sortable: false,
                orderable: false,
                mRender: function (data, type, row, meta) {
                  var articleId = data.id;
                  return '<div class="common-table__dots-parent"><button class="fa fa-ellipsis-v common-table__dots" type="button" data-target="' + meta.row + '"></button><div class="table-menu"  id="' + meta.row + '"><button id="' + articleId + '" type="button" class="table-menu__item">Edit</button><div class="table-menu__divider"></div><button id="' + articleId + '" type="button"  class="table-menu__modal">Delete</button><div class="table-menu__arrow-right"></div></div></div>'
                },
                targets: -1,
              }
            ],
            stateSave: true,
            bRetrieve: true,
            oLanguage: { sProcessing: '<div class="loader" ></div>' },
            'bPaginate': true,
            'bFilter': true,
            'bJQueryUI': true,
            'bLengthChange': true,
            'bStateSave': true,
            'bDeferRender': true,
            'bAutoWidth': false,
            order: [[1, 'asc']],
            // scrollX: true
          });

        $(window).on('resize', function () {
          table.columns.adjust();
        });

        handleResetColumns(false);
        toggleAllColumns(hideColumnList, true, false);

        $(window).on('click', function () {
          $('.table-menu').hide();
        });

        $('#data-table tbody').on('click', '.common-table__dots', function (e) {
          // onclick=(closeTicket('+meta.row+')
          e.stopPropagation();
          var btnId = $(this).attr('data-target');
          var popUpId = '#' + btnId;
          if ($(popUpId).css('display') == 'none') {
            $('.table-menu').hide();
          }
          if (popUpId) {
            $(popUpId).toggle();
          }
        });

        $('#data-table tbody').on('click', '.table-menu__item', function () {
          var article = table.row($(this).parents('tr')).data();
          setArticleDetails(article);
          setIsUpdateArticle(true);
        });

        $('#data-table tbody').on('click', '.table-menu__modal', function () {
          var article = table.row($(this).parents('tr')).data();
          setArticleDetails(article);
          setShowdeleteConfirmModal(true);
        });
      });
      setIsShowHideOptions(true);
    } else {
      getData([], 0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataList]);

  const handleConfirm = (id, obj) => {
    setIsShowLoader(true);
    if (obj.file.file) {
      const formData = new FormData();
      formData.append('file', obj.file.file);
      uploadImageFile((response) => {
        const { success, message } = response;
        if (success) {
          if (id === 'updateArticleModal') {
            handleUpdateArticle(obj);
          } else {
            handleAddArticle(obj);
          }
        } else {
          setAlertText(message);
          setIsShowLoader(false);
          setShowConfirmModal(true);
        }
      }, formData)
    } else {
      if (id === 'updateArticleModal') {
        handleUpdateArticle(obj);
      } else {
        handleAddArticle(obj);
      }
    }
  }

  const handleUpdateArticle = (obj) => {
    setIsShowLoader(true);
    const payload = {
      'id': articleDetails.id,
      'url': obj.text1,
      'description': obj.desc1Value,
      'title': obj.text2,
      'image': obj.file.image,
      'tag': obj.desc2Value
    };
    updateArticle((response) => {
      const { success, message } = response;
      if (success) {
        getData([], 0);
        setArticleDetails({});
        setIsUpdateArticle(false);
      }
      setAlertText(message);
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  }

  const handleAddArticle = (obj) => {
    setIsShowLoader(true);
    const payload = {
      'url': obj.text1,
      'description': obj.desc1Value,
      'title': obj.text2,
      'image': obj.file.image,
      'tag': obj.desc2Value
    };
    createArticle((response) => {
      const { success, message } = response;
      if (success) {
        getData([], 0);
        setIsAddArticle(false);
        setArticleDetails({});
      }
      setAlertText(message);
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  }

  const handleDeleteArticle = () => {
    setShowdeleteConfirmModal(false);
    setIsShowLoader(true);
    const payload = {
      'ArticleId': articleDetails.id
    }
    deleteArticle((response) => {
      const { success, message } = response;
      if (success) {
        getData([], 0);
        setArticleDetails({});
      }
      setAlertText(message);
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  };

  const getDropdownButtonLabel = ({ placeholderButtonLabel, value }) => {
    if (value && value.some((o) => o.value === '*')) {
      return `${placeholderButtonLabel}: All`;
    } else {
      const values = [];
      value.map((val, i) => {
        if (i < value.length - 1) {
          values.push(val.value);
          val.checked = false;
        }
      });
      values.splice(0, 0, value[value.length - 1]?.value);
      return `${placeholderButtonLabel}: ${values.join(',')}`;
    }
  };

  const handleResetColumns = (isFromToggleColumns) => {
    if (isFromToggleColumns) {
      $('#data-table').DataTable().columns().visible(true);
      $('#data-table thead tr:eq(1)').remove();
    }
    $('#data-table thead tr').clone(true).appendTo('#data-table thead');
    $('#data-table thead tr:eq(1) th').each(function (i) {
      var title = $(this).text();
      $(this).off('click.DT');
      $(this).removeAttr('aria-controls');
      $(this).removeAttr('aria-sort');
      $(this).removeClass(
        'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
      );
      if (title !== 'Actions') {
        $(this).html(
          '<input type="text" placeholder="Search ' + title + '" />'
        );
        $('input', this).on('keyup change', function () {
          if ($('#data-table').DataTable().column(i).search() !== this.value) {
            $('#data-table').DataTable().column(i).search(this.value).draw();
          }
        });
      }
      else {
        $(this).html(
          <th ></th>
        );
      }
    });
    if (!isFromToggleColumns) {
      $('#data-table thead tr:eq(0) th').each(function (i) {
        if (i === columnsList.length - 1) {
          $(this).removeAttr('aria-controls');
          $(this).removeAttr('aria-sort');
          $(this).removeClass(
            'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
          );
        }
      });
    }
  }

  const toggleAllColumns = (value, isShowColumn, isHideSearch) => {
    if ($.fn.dataTable.isDataTable('#data-table')) {
      handleResetColumns(true);
    }
    let values = [];
    value.map((val) => {
      val.checked = false;
      var valId = val.id - 1;
      if (val.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
        values.push(val);
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
    if (values?.length !== 0) {
      setFilteredColumnValues(values);
      setSelectedOptions([
        { label: 'All', value: '*' },
        ...values,
      ]);
    }
  };

  const toggleColumn = (value, isShowColumn, isHideSearch) => {
    var valId = value.id - 1;
    $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
    $('#data-table thead tr:eq(1) th').each(function () {
      if (value.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
  };

  const onChange = (value, event) => {
    if (event.action === 'select-option' && event.option.value === '*') {
      toggleAllColumns(hideColumnList, true, false);
      setSelectedOptions([{ label: 'All', value: '*' }, ...filteredColumnValues]);
    } else if (
      event.action === 'deselect-option' &&
      event.option.value === '*'
    ) {
      toggleAllColumns(hideColumnList, false, true);
      setSelectedOptions([]);
    } else if (event.action === 'deselect-option') {
      toggleColumn(event.option, false, true);
      setSelectedOptions(value.filter((o) => o.value !== '*'));
    } else {
      toggleColumn(event.option, true, false);
      if (filteredColumnValues.length === value.length) {
        setSelectedOptions([{ label: 'All', value: '*' }, ...value]);
      } else {
        setSelectedOptions(value);
      }
    }
  };

  return (
    <div>
      <div className='pageHeader'>
        <Name tabTitle='Content-Management' title='Article' />
        <div>
          <Button
            className='pageHeader__button'
            buttonClick={() => {
              setIsAddArticle(true);
            }}
          >
            Add New Article
          </Button>
        </div>
      </div>
      <div className='common-table'>
        {isShowHideOptions &&
          <div className='common-table__toggle'>
            <MultiSelect
              options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
              placeholderButtonLabel='Show '
              getDropdownButtonLabel={getDropdownButtonLabel}
              value={selectedOptions}
              onChange={onChange}
              setState={setSelectedOptions}
              hideSearch={true}
            />
          </div>
        }
        <table id='data-table' className='display' width='100%'></table>
      </div>

      {isAddArticle ? (
        <PopUp id='addArticleModal'
          onConfirm={handleConfirm} onCancel={() => { setIsAddArticle(false); }} commonTitle='Add New Article'
          input1Placeholder='Paste URL' input2Placeholder='Title' input3Placeholder='Image URL'
          isShowInput1={true} isShowInput2={true} isShowInput6={true}
          isShowDescription1={true} isShowDescription2={true} desc1Placeholder='Description'
          desc2Placeholder='Enter Tags by Comma Separated Values' btnText='DONE' />
      ) :
        null
      }
      {isUpdateArticle ? (
        <PopUp id='updateArticleModal'
          onConfirm={handleConfirm} onCancel={() => { setIsUpdateArticle(false); }} commonTitle='Edit Article'
          input1Placeholder='Paste URL' input2Placeholder='Title' input3Placeholder='Image URL'
          isShowInput1={true} isShowInput2={true} isShowInput6={true}
          input1Value={articleDetails.url} input2Value={articleDetails.title} updateFile={articleDetails.image}
          isShowDescription1={true} isShowDescription2={true} desc1Placeholder='Description'
          desc1TextValue={articleDetails.description} desc2TextValue={articleDetails.tag} desc2Placeholder='Enter Tags by Comma Separated Values'
          btnText='DONE' />
      ) : (
        ''
      )}
      {
        showdeleteConfirmModal && (
          <Confirm buttonText={'OK'} isCancelRequired={true} confirmTitle={'Are you sure you want to Delete the Article?'}
            onConfirm={handleDeleteArticle} onCancel={() => { setShowdeleteConfirmModal(false) }} />
        )
      }
      {
        showConfirmModal && (
          <Confirm buttonText={'OK'} confirmTitle={alertText} isCancelRequired={false}
            onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
        )
      }
      {isShowLoader ? <Loader /> : null}

    </div>
  );
};

Articles.propTypes = {
};

Articles.defaultProps = {
};

export default React.memo(Articles);
