/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import Name from '../../../../../components/name';
import Button from '../../../../../components/button/index';
import PopUp from '../../../../../components/popup/index';
import Confirm from '../../../../../components/confirmModal/confirm';
import { getFAQList, createFAQ, updateFAQ, deleteFAQ } from '../../../../../utils/apiCalls';
import Loader from '../../../../../components/loader';
import MultiSelect from 'react-multiselect-checkboxes';
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import './index.scss';

//Datatable Modules
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import jsZip from 'jszip';
import 'datatables.net-buttons/js/buttons.html5.min';
import 'datatables.net-buttons/js/buttons.print.min';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
window.JSZip = jsZip;

const FAQ = () => {
  const [isAddFaq, setIsAddFaq] = useState(false);
  const [isEditFaq, setIsEditFaq] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [columnsList, setColumnsList] = useState();
  const [dataList, setDataList] = useState();
  const [hideTable, setHideTable] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [faqId, setFaqId] = useState('');
  const [faqDetails, setFaqDetails] = useState({});
  const [faqHideList, setFaqHideList] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isShowHideOptions, setIsShowHideOptions] = useState(false);
  const [filteredColumnValues, setFilteredColumnValues] = useState([]);
  const [rowIndex, setRowIndex] = useState('');

  const getData = () => {
    setIsShowLoader(true);
    getFAQList((response) => {
      const { success, message, data } = response;
      setIsShowLoader(false);
      if (success && data?.data?.length) {
        var values = data.data;
        let columnNames = [];
        var column = [];
        let hideValues = [];
        columnNames = Object.keys(values[0]);
        for (var i in columnNames) {
          column.push({
            data: columnNames[i],
            title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1),
            render: function (value) {
              if (value?.length > 40 && (typeof value === 'string' || value instanceof String)) {
                value = value.substring(0, 40) + '...';
              }
              return value;
            }
          });
          if (columnNames.length - 1 == i) {
            let obj = {
              title: 'Actions',
              className: 'noExport'
            }
            column.push(obj);
          }
          let obj1 = {};
          obj1 = {
            label: columnNames[i], value: columnNames[i], id: parseInt(i) + 1, checked: true
          }
          hideValues.push(obj1);
          if (columnNames.length - 1 == i) {
            obj1 = {
              label: 'Actions', value: 'Actions', id: parseInt(i) + 2, checked: true
            }
            hideValues.push(obj1);
          }
        }
        setHideTable(true);
        setFaqHideList(hideValues);
        setColumnsList(column);
        setDataList(values);
      } else if (!success) {
        setAlertText(message);
        setShowConfirmModal(true);
        setHideTable(false);
      }
    });
  };

  useEffect(() => {
    if (hideTable) {
      $(document).ready(function () {
        if ($.fn.dataTable.isDataTable('#data-table')) {
          $('#data-table').DataTable().destroy();
          $('#data-table').empty();
        }
        var table = $('#data-table')
          .DataTable({
            data: dataList,
            columns: columnsList,
            paging: true,
            responsive: true,
            ordering: true,
            dom: 'ifrtlpB',
            buttons: [
              {
                extend: 'collection', text: '', className: 'common-table__export-btn',
                buttons: [
                  {
                    extend: 'csv', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'excel', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'pdf', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  }
                ],
              },
            ],
            columnDefs: [
              {
                data: null,
                sortable: false,
                orderable: false,
                mRender: function (data, type, row, meta) {
                  return '<div class="common-table__dots-parent"><button class="fa fa-ellipsis-v common-table__dots" type="button" data-target="' + meta.row + '"></button><div class="table-menu"  id="' + meta.row + '"><button id="' + data.id + '" type="button" class="table-menu__item">Edit</button><div class="table-menu__divider"></div><button id="' + data.id + '" type="button" class="table-menu__modal">Delete</button><div class="table-menu__arrow-right"></div></div></div>'
                },
                targets: [-1],
              },
            ],
            stateSave: true,
            bRetrieve: true,
            oLanguage: { sProcessing: '<div class="loader" ></div>' },
            'bPaginate': true,
            'bFilter': true,
            'bJQueryUI': true,
            'bLengthChange': true,
            'bStateSave': true,
            'bDeferRender': true,
            'bAutoWidth': true,
            order: [[1, 'asc']]
          });

        $(window).on('click', function (e) {
          $('.table-menu').hide();
        });

        $('#data-table tbody').on('click', '.common-table__dots', function (e) {
          e.stopPropagation();
          var btnId = $(this).attr('data-target');
          var popUpId = '#' + btnId;
          if ($(popUpId).css('display') == 'none') {
            $('.table-menu').hide();
          }
          if (popUpId) {
            $(popUpId).toggle();
          }
        });

// delete operation starts
        $('#data-table tbody').on('click', '.table-menu__modal', function (e) {
          var id = $(this).attr('id');
          var row = table.row( this ).index();
          setRowIndex(row);
          setFaqId(id);
          setShowDeleteConfirmModal(true);
        });
//update operation starts
        $('#data-table tbody').on( 'click', 'tr', function () {
         var row = table.row( this ).index();
         setRowIndex(row);
             } );
//edit operation starts
        $('#data-table tbody').on('click', '.table-menu__item', function (e) {
          var faq = table.row($(this).parents('tr')).data();
          setFaqDetails(faq);
          setIsEditFaq(true);
        });
        handleResetColumns(false);
        toggleAllColumns(faqHideList, true, false);
      });
      setIsShowHideOptions(true);
    } else {
      getData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataList]);

    // eslint-disable-next-line no-unused-vars
    function applyData(data, append, rowId) {
      let table = $('#data-table').DataTable();
      if (append === true) {
        table.row.add(data);
      } else {
        var list = table.rows().data().toArray();
        var rowIndex = list.findIndex(val => val.id === rowId);
        table.row(rowIndex).data(data).invalidate();
      }
      table.draw(false);
    }

  const handleOnSubmitFaqModal = (id, obj) => {
    setIsShowLoader(true);
    if (id === 'addFaq') {
      let payload = {
        title: obj.text1,
        description: obj.desc1Value
      }
      createFAQ((response) => {
        const { success, message } = response;
        if (success) {
           let obj = {
          id: response.data.id,
          title: response.data.title,
          description: response.data.description
        }
      applyData(obj, true);
        }
        setAlertText(message);
        setIsShowLoader(false);
        setShowConfirmModal(true);
      }, payload);
      setIsAddFaq(false);
    }
    else if (id === 'editFaq') {
      if (faqDetails) {
        let payload = {
          'id': faqDetails.id,
          'title': obj.text1,
          'description': obj.desc1Value
        }
        updateFAQ((response) => {
          const { success, message } = response;
          if (success === true) {
          $('#data-table').DataTable().row(rowIndex).data( payload );
          setAlertText('FAQ updated successfully !');
          } else {
            setAlertText(message);
          }
          setIsShowLoader(false);
          setShowConfirmModal(true);
        }, payload)
      }
      setIsEditFaq(false);
    }
  }

  const handleRemoveFaqModal = () => {
    setShowDeleteConfirmModal(false);
    setIsShowLoader(true);
    if (faqId) {
      let payload = {
        FAQId: faqId
      }
      deleteFAQ((response) => {
        const { success, message } = response
        if (success) {
          $('#data-table').DataTable().row(rowIndex).remove();
          $('#data-table').DataTable().draw();
          setFaqDetails({});
        }
        setAlertText(message);
        setIsShowLoader(false);
        setShowConfirmModal(true);
      }, payload)
    }
  }

  const getDropdownButtonLabel = ({ placeholderButtonLabel, value }) => {
    if (value && value.some((o) => o.value === '*')) {
      return `${placeholderButtonLabel}: All`;
    } else {
      const values = [];
      value.map((val, i) => {
        if (i < value.length - 1) {
          values.push(val.value);
          val.checked = false;
        }
      });
      values.splice(0, 0, value[value.length - 1]?.value);
      return `${placeholderButtonLabel}: ${values.join(',')}`;
    }
  };

  const handleResetColumns = (isFromToggleColumns) => {
    if (isFromToggleColumns) {
      $('#data-table').DataTable().columns().visible(true);
      $('#data-table thead tr:eq(1)').remove();
    }
    $('#data-table thead tr').clone(true).appendTo('#data-table thead');
    $('#data-table thead tr:eq(1) th').each(function (i) {
      var title = $(this).text();
      $(this).off('click.DT');
      $(this).removeAttr('aria-controls');
      $(this).removeAttr('aria-sort');
      $(this).removeClass(
        'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
      );
      if (title !== 'Actions') {
        $(this).html(
          '<input type="text" placeholder="Search ' + title + '" />'
        );
        $('input', this).on('keyup change', function () {
          if ($('#data-table').DataTable().column(i).search() !== this.value) {
            $('#data-table').DataTable().column(i).search(this.value).draw();
          }
        });
      }
      else {
        $(this).html(
          <th ></th>
        );
      }
    });
    if (!isFromToggleColumns) {
      $('#data-table thead tr:eq(0) th').each(function (i) {
        if (i === columnsList.length - 1) {
          $(this).removeAttr('aria-controls');
          $(this).removeAttr('aria-sort');
          $(this).removeClass(
            'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
          );
        }
      });
    }
  }

  const toggleAllColumns = (value, isShowColumn, isHideSearch) => {
    if ($.fn.dataTable.isDataTable('#data-table')) {
      handleResetColumns(true);
    }
    let values = [];
    value.map((val) => {
      val.checked = false;
      var valId = val.id - 1;
      if (val.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
        values.push(val);
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
    if (values?.length !== 0) {
      setFilteredColumnValues(values);
      setSelectedOptions([
        { label: 'All', value: '*' },
        ...values,
      ]);
    }
  };

  const toggleColumn = (value, isShowColumn, isHideSearch) => {
    var valId = value.id - 1;
    $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
    $('#data-table thead tr:eq(1) th').each(function () {
      if (value.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
  };

  const onChange = (value, event) => {
    if (event.action === 'select-option' && event.option.value === '*') {
      toggleAllColumns(faqHideList, true, false);
      setSelectedOptions([{ label: 'All', value: '*' }, ...filteredColumnValues]);
    } else if (
      event.action === 'deselect-option' &&
      event.option.value === '*'
    ) {
      toggleAllColumns(faqHideList, false, true);
      setSelectedOptions([]);
    } else if (event.action === 'deselect-option') {
      toggleColumn(event.option, false, true);
      setSelectedOptions(value.filter((o) => o.value !== '*'));
    } else {
      toggleColumn(event.option, true, false);
      if (filteredColumnValues.length === value.length) {
        setSelectedOptions([{ label: 'All', value: '*' }, ...value]);
      } else {
        setSelectedOptions(value);
      }
    }
  };

  return (
    <div>
      <div className='pageHeader'>
        <Name tabTitle='Content-Management' title={'FAQ'} />
        <div >
          <Button
            className='pageHeader__button'
            buttonClick={() => setIsAddFaq(true)}
          >
            Add FAQ
          </Button>
        </div>
        {
          showDeleteConfirmModal && (
            <Confirm buttonText={'OK'} confirmTitle={'Are you sure want to delete the FAQ ?'} isCancelRequired={true}
              onConfirm={handleRemoveFaqModal} onCancel={() => { setShowDeleteConfirmModal(false) }} />
          )
        }
        {
          showConfirmModal && (
            <Confirm buttonText={'OK'} confirmTitle={alertText} isCancelRequired={false}
              onConfirm={() => setShowConfirmModal(false)} onCancel={() => { setShowConfirmModal(false) }} />
          )
        }
        {isAddFaq ? (
          <PopUp
            id='addFaq'
            onCancel={() => setIsAddFaq(false)}
            isShowInput1={true}
            isShowDescription1={true}
            input1Placeholder='Title'
            desc1Placeholder='Description'
            commonTitle='Add FAQ'
            onConfirm={handleOnSubmitFaqModal}
            btnText='DONE'
          />
        ) : (
          null
        )}
        {isEditFaq ? (
          <PopUp
            id='editFaq'
            onConfirm={handleOnSubmitFaqModal}
            onCancel={() => setIsEditFaq(false)}
            isShowInput1={true}
            isShowDescription1={true}
            input1Placeholder='Title'
            input1Value={faqDetails.title}
            desc1TextValue={faqDetails.description}
            desc1Placeholder='Description'
            commonTitle='Edit FAQ'
            btnText='UPDATE'
          />
        ) : (
          null
        )}
      </div>
      <div className='common-table'>
        {isShowHideOptions &&
          <div className='common-table__toggle'>
            <MultiSelect
              options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
              placeholderButtonLabel='Show '
              getDropdownButtonLabel={getDropdownButtonLabel}
              value={selectedOptions}
              onChange={onChange}
              setState={setSelectedOptions}
              hideSearch={true}
            />
          </div>
        }
        <table id='data-table' className='display' width='100%'></table>
      </div>
      {isShowLoader && <Loader />}
    </div>

  );
}

FAQ.propTypes = {
};

FAQ.defaultProps = {
}

export default React.memo(FAQ);
