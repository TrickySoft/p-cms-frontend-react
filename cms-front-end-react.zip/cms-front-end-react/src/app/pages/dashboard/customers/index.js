import React from 'react';
import './index.scss';
import Name from '../../../components/name';

const Customers = () => {

  return (
    <div className='u_width'>
      <div className='u_page'>
        <Name title={'Customers'} />
        <div className='customers'> Coming Soon...!</div>
      </div>
    </div>
  )
}

Customers.propTypes = {
};

Customers.defaultProps = {
}

export default React.memo(Customers);
