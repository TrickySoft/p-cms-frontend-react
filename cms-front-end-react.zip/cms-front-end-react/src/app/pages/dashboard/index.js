/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import './index.scss';
import Sidebar from '../../components/sidebar';
import Customer from './customer';
import Customers from './customers';
import Machines from './machines';
import ContentManagement from './content-management';
import Notifications from './notifications';
import Roles from './roles';
import Reasons from './reasons';

const Dashboard = () => {
  const options = [
    {
      name: 'customer',
      label: 'Customer',
      hasOptions: true,
      subOptions: [
        {
          name: 'userList',
          label: 'UserList',
        },
        {
          name: 'serviceRequest',
          label: 'Service Request'
        },
        {
          name: 'contactUS',
          label: 'Contact US'
        },
        {
          name: 'feedback',
          label: 'Feedback'
        }
      ]
    },
    {
      name: 'customerNames',
      label: 'Joe & Vijay',
      hasOptions: false
    },
    {
      name: 'machines',
      label: 'Machines',
      hasOptions: true,
      subOptions: [
        {
          name: 'make',
          label: 'Make'
        }
      ]
    },
    {
      name: 'contentManagement',
      label: 'Content Management',
      hasOptions: true,
      subOptions: [
        {
          name: 'video',
          label: 'Video'
        },
        {
          name: 'articles',
          label: 'Articles'
        },
        {
          name: 'banners',
          label: 'Banners'
        },
        {
          name: 'faq',
          label: 'FAQ'
        },
        {
          name: 'termsConditions',
          label: 'Terms & Conditions'
        },
        {
          name: 'codes&manuals',
          label: 'Codes & Manuals'
        }
      ]
    },
    {
      name: 'reasons',
      label: 'Reasons',
      hasOptions: true,
      subOptions: [
        {
          name: 'contactUs',
          label: 'Contact Us'
        },
        {
          name: 'serviceRequest',
          label: 'Service Request'
        }
      ]
    },
    {
      name: 'notifications',
      label: 'Notifications',
      hasOptions: false
    },
    {
      name: 'roles',
      label: 'Roles',
      hasOptions: false
    }
  ];

  const [activeTab, setActiveTab] = useState(options[0].name);
  const [activeSubTab, setActiveSubTab] = useState(options[0].subOptions ? options[0].subOptions[0].name : '');
  const [prevActiveTab, setPrevActiveTab] = useState(options[0].name);
  const [prevActiveSubTab, setPrevActiveSubTab] = useState(options[0].subOptions ? options[0].subOptions[0] : '');

  const handleTabs = (option) => {
    if (prevActiveTab !== option.name && option.subOptions) {
      setActiveTab(prevActiveTab);
    } else if (prevActiveTab === option.name && option.subOptions) {
      handleSubTab(prevActiveSubTab, option);
      setPrevActiveTab(option.name);
    } else {
      setActiveTab(option.name);
      handleSubTab({}, option);
      setPrevActiveTab(option.name);
    }
  }

  const handleSubTab = (subOption, option) => {
    setActiveTab(option?.name);
    setPrevActiveTab(option?.name);
    if (subOption) {
      setActiveSubTab(subOption.name);
      setPrevActiveSubTab(subOption);
    }
  }

  return (
    <div className='customer__wrapper u_flex'>
      <div className='customer__sidebar'>
        <Sidebar activeSubTab={activeSubTab} options={options} onTabClick={(option) => { handleTabs(option) }}
          onSubTabClick={(subOption, option) => { handleSubTab(subOption, option) }} />
      </div>
      {activeTab === 'customer' &&
        <Customer activeSubTab={activeSubTab} />
      }
      {activeTab === 'customerNames' &&
        <Customers />
      }
      {activeTab === 'machines' &&
        <Machines />
      }
      {activeTab === 'contentManagement' &&
        <ContentManagement activeSubTab={activeSubTab} />
      }
      {activeTab === 'reasons' &&
        <Reasons activeSubTab={activeSubTab} />
      }
      {activeTab === 'notifications' &&
        <Notifications />
      }
      {activeTab === 'roles' &&
        <Roles />
      }
    </div>
  );
};

export default Dashboard;
