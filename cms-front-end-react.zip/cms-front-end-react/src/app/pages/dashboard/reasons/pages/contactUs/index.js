import React, { useEffect, useState } from 'react';
import Name from '../../../../../components/name';
import MultiSelect from 'react-multiselect-checkboxes';
import Button from '../../../../../components/button/index';
import Confirm from '../../../../../components/confirmModal/confirm';
import './index.scss';
import { getContactUsReasonList, createReason } from '../../../../../utils/apiCalls';
import PopUp from '../../../../../components/popup';
import Loader from '../../../../../components/loader';

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

//Datatable Modules
import 'datatables.net-dt/js/dataTables.dataTables';
import 'datatables.net-dt/css/jquery.dataTables.min.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import jsZip from 'jszip';
import 'datatables.net-buttons/js/buttons.html5.min';
import 'datatables.net-buttons/js/buttons.print.min';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
window.JSZip = jsZip;

const ReasonContactUs = () => {
  const [addReason, setAddReason] = useState(false);
  const [alertText, setAlertText] = useState('');
  const [columnsList, setColumnsList] = useState();
  const [dataList, setDataList] = useState();
  const [hideTable, setHideTable] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [hideColumnList, setHideColumnList] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [isShowHideOptions, setIsShowHideOptions] = useState(false);
  const [filteredColumnValues, setFilteredColumnValues] = useState([]);

  const dropdownList = [
    {
      'value': 'contactUs',
      'name': 'Contact Us'
    },
    {
      'value': 'serviceRequest',
      'name': 'Service Request'
    }
  ]

  const getData = () => {
    setIsShowLoader(true);
    getContactUsReasonList((response) => {
      const { success, message, data } = response;
      setIsShowLoader(false);
      if (success && data?.length) {
        var values = data.map((val, index) => {
          let obj = {
            id: index + 'abcedcdc'
          }
          // eslint-disable-next-line no-unused-vars
          for (let i in obj) {
            for (let prop in val) {
              obj[prop] = val[prop];
            }
            break;
          }
          return obj;
        });
        let columnNames = [];
        var column = [];
        let hideValues = [];
        columnNames = Object.keys(values[0]);
        for (var i in columnNames) {
          column.push({
            data: columnNames[i],
            title: columnNames[i].charAt(0).toUpperCase() + columnNames[i].slice(1)
          });
          let obj1 = {
            label: columnNames[i], value: columnNames[i], id: parseInt(i) + 1, checked: true
          }
          hideValues.push(obj1);
        }
        setHideTable(true);
        setHideColumnList(hideValues);
        setColumnsList(column);
        setDataList(values);
      } else if (!success) {
        setAlertText(message);
        setShowConfirmModal(true);
        setHideTable(false);
      }
    });
  };

  useEffect(() => {
    if (hideTable) {
      $(document).ready(function () {
        if ($.fn.dataTable.isDataTable('#data-table')) {
          $('#data-table').DataTable().destroy();
          $('#data-table').empty();
        }
        $('#data-table')
          .DataTable({
            data: dataList,
            columns: columnsList,
            paging: true,
            responsive: true,
            ordering: true,
            dom: 'ifrtlpB',
            buttons: [
              {
                extend: 'collection', text: '', className: 'common-table__export-btn',
                buttons: [
                  {
                    extend: 'csv', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'excel', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  },
                  {
                    extend: 'pdf', className: 'common-table__export-btn--options',
                    exportOptions: { columns: [0, 'thead th:not(.noExport)'] }
                  }
                ],
              },
            ],
            stateSave: true,
            bRetrieve: true,
            oLanguage: { sProcessing: '<div class="loader" ></div>' },
            'bPaginate': true,
            'bFilter': true,
            'bJQueryUI': true,
            'bLengthChange': true,
            'bStateSave': true,
            'bDeferRender': true,
            'bAutoWidth': true,
            order: [[1, 'asc']]
          });
        handleResetColumns(false);
        toggleAllColumns(hideColumnList, true, false);
      });
      setIsShowHideOptions(true);
    } else {
      getData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataList]);

  const handleAddModal = (id, obj) => {
    setIsShowLoader(true);
    let payload = {
      'category': obj.selectedDropdown1Value.value,
      'reason': obj.text1
    }
    createReason((response) => {
      const { success, message } = response;
      setIsShowLoader(false);
      if (success) {
        getData();
        setAlertText('Successfully added the Reason !');
        setShowConfirmModal(true);
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
      }
    }, payload)
    setAddReason(false);
  };

  const getDropdownButtonLabel = ({ placeholderButtonLabel, value }) => {
    if (value && value.some((o) => o.value === '*')) {
      return `${placeholderButtonLabel}: All`;
    } else {
      const values = [];
      value.map((val, i) => {
        if (i < value.length - 1) {
          values.push(val.value);
          val.checked = false;
        }
      });
      values.splice(0, 0, value[value.length - 1]?.value);
      return `${placeholderButtonLabel}: ${values.join(',')}`;
    }
  };

  const handleResetColumns = (isFromToggleColumns) => {
    if (isFromToggleColumns) {
      $('#data-table').DataTable().columns().visible(true);
      $('#data-table thead tr:eq(1)').remove();
    }
    $('#data-table thead tr').clone(true).appendTo('#data-table thead');
    $('#data-table thead tr:eq(1) th').each(function (i) {
      var title = $(this).text();
      $(this).off('click.DT');
      $(this).removeAttr('aria-controls');
      $(this).removeAttr('aria-sort');
      $(this).removeClass(
        'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
      );
      if (title !== 'Actions') {
        $(this).html(
          '<input type="text" placeholder="Search ' + title + '" />'
        );
        $('input', this).on('keyup change', function () {
          if ($('#data-table').DataTable().column(i).search() !== this.value) {
            $('#data-table').DataTable().column(i).search(this.value).draw();
          }
        });
      }
      else {
        $(this).html(
          <th ></th>
        );
      }
    });
    if (!isFromToggleColumns) {
      $('#data-table thead tr:eq(0) th').each(function (i) {
        if (i === columnsList.length - 1) {
          $(this).removeAttr('aria-controls');
          $(this).removeAttr('aria-sort');
          $(this).removeClass(
            'context-menu sorting sorting_desc sorting_asc sorting:after sorting_asc:after'
          );
        }
      });
    }
  }

  const toggleAllColumns = (value, isShowColumn, isHideSearch) => {
    if ($.fn.dataTable.isDataTable('#data-table')) {
      handleResetColumns(true);
    }
    let values = [];
    value.map((val) => {
      val.checked = false;
      var valId = val.id - 1;
      if (val.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
        values.push(val);
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
    if (values?.length !== 0) {
      setFilteredColumnValues(values);
      setSelectedOptions([
        { label: 'All', value: '*' },
        ...values,
      ]);
    }
  };

  const toggleColumn = (value, isShowColumn, isHideSearch) => {
    var valId = value.id - 1;
    $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
    $('#data-table thead tr:eq(1) th').each(function () {
      if (value.label !== 'id') {
        $('#data-table').dataTable().fnSetColumnVis(valId, isShowColumn);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            if (isHideSearch) {
              $(this).hide();
              $(this).attr('hidden', true);
            } else {
              $(this).show();
              $(this).attr('hidden', false);
            }
          }
        });
      } else {
        $('#data-table').dataTable().fnSetColumnVis(valId, false);
        $('#data-table thead tr:eq(1) th').each(function (i) {
          if (i == valId) {
            $(this).hide();
            $(this).attr('hidden', true);
          }
        });
      }
    });
  };

  const onChange = (value, event) => {
    if (event.action === 'select-option' && event.option.value === '*') {
      toggleAllColumns(hideColumnList, true, false);
      setSelectedOptions([{ label: 'All', value: '*' }, ...filteredColumnValues]);
    } else if (
      event.action === 'deselect-option' &&
      event.option.value === '*'
    ) {
      toggleAllColumns(hideColumnList, false, true);
      setSelectedOptions([]);
    } else if (event.action === 'deselect-option') {
      toggleColumn(event.option, false, true);
      setSelectedOptions(value.filter((o) => o.value !== '*'));
    } else {
      toggleColumn(event.option, true, false);
      if (filteredColumnValues.length === value.length) {
        setSelectedOptions([{ label: 'All', value: '*' }, ...value]);
      } else {
        setSelectedOptions(value);
      }
    }
  };

  return (
    <div>
      <div className='pageHeader'>
        <Name tabTitle='Reasons' title='Contact Us' />
        <div>
          <Button
            className='pageHeader__button'
            buttonClick={() => {
              setAddReason(true);
            }}
          >
            Add Reason
          </Button>
        </div>
      </div>
      <div className='common-table'>
        {isShowHideOptions &&
          <div className='common-table__toggle'>
            <MultiSelect
              options={[{ label: 'All', value: '*' }, ...filteredColumnValues]}
              placeholderButtonLabel='Show '
              getDropdownButtonLabel={getDropdownButtonLabel}
              value={selectedOptions}
              onChange={onChange}
              setState={setSelectedOptions}
              hideSearch={true}
            />
          </div>
        }
        <table id='data-table' className='display' width='100%'></table>
      </div>
      {addReason ? (
        <PopUp
          id='addReason'
          onConfirm={handleAddModal} onCancel={() => { setAddReason(false); }} commonTitle='Add New Reason'
          input1Placeholder='Reason' isShowInput1={true} isDropdown1Required={true}
          dropdown1List={dropdownList}
          dropdown1Placeholder='Select Categories'
          btnText='DONE' />
      ) :
        null
      }
      {
        showConfirmModal && (
          <Confirm buttonText={'OK'} confirmTitle={alertText} isCancelRequired={false}
            onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
        )
      }
      {isShowLoader ? <Loader /> : null}
    </div>
  );
};

ReasonContactUs.propTypes = {
};

ReasonContactUs.defaultProps = {
};

export default React.memo(ReasonContactUs);
