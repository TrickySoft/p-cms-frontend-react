import React from 'react';
import './index.scss';
import ServiceRequest from './pages/serviceRequest';
import ContactUs from './pages/contactUs';
import PropTypes from 'prop-types';

const Reasons = ({ activeSubTab }) => {
  return (
    <div className='u_width'>
      <div className='u_page'>
        {activeSubTab === 'contactUs' &&
          <ContactUs />
        }
        {activeSubTab === 'serviceRequest' &&
          <ServiceRequest />
        }
      </div>
    </div>
  );
};

Reasons.propTypes = {
  activeSubTab: PropTypes.string
};

Reasons.defaultProps = {
  activeSubTab: ''
}

export default React.memo(Reasons);
