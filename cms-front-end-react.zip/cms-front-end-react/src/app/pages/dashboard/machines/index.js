/* eslint-disable no-unused-vars */
import React, { useEffect, useState, useRef } from 'react';
import './index.scss';
// import PropTypes from 'prop-types';
import Name from '../../../components/name';
import {
  getMachineCategoryMakeWiseList, updateMachine, createMachineCategory, updateMachineCategory,
  deleteMachineCategory, createMachineCategoryModel, deleteModel
} from '../../../utils/apiCalls';
import PopUp from '../../../components/popup';
import Button from '../../../components/button';
import Confirm from '../../../components/confirmModal/confirm';
import Loader from '../../../components/loader';

const Machines = () => {
  const menuRef = useRef(null);
  const menuRef1 = useRef(null);
  const menuRef2 = useRef(null);

  const [machines, setMachines] = useState([]);
  const [isActiveMake, setIsActiveMake] = useState(0);
  const [isActiveMakeOption, setIsActiveMakeOption] = useState(0);
  const [isActiveCategory, setIsActiveCategory] = useState(0);
  const [isActiveCategoryOption, setIsActiveCategoryOption] = useState(0);
  const [isActiveModel, setIsActiveModel] = useState(0);
  const [isshowCategories, setIsshowCategories] = useState(false);
  const [isshowModels, setIsshowModels] = useState(false);
  const [isAddCategory, setIsAddCategory] = useState(false);
  const [isUpdateCategory, setIsUpdateCategory] = useState(false);
  const [isUpdateMachine, setIsUpdateMachine] = useState(false);
  const [isAddModel, setIsAddModel] = useState(false);

  const [dropdownList, setDropdownList] = useState([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [showDeleteCategoryConfirmModal, setShowDeleteCategoryConfirmModal] = useState(false);

  const [alertText, setAlertText] = useState('');
  const [isShowModal, setIsShowModal] = useState(false);
  const [isShowMachineModal, setIsShowMachineModal] = useState(false);
  const [isShowModelModal, setIsShowModelModal] = useState(false);
  const [isShowLoader, setIsShowLoader] = useState(false);
  const [actionData, setActionData] = useState([]);

  useEffect(() => {
    getData();
    function handleClickOutside(event) {
      if (menuRef1.current && !menuRef1.current.contains(event.target)) {
        setIsShowModal(false);
      } else if (menuRef2.current && !menuRef2.current.contains(event.target)) {
        setIsShowModelModal(false);
      } else if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsShowMachineModal(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuRef1, menuRef2, menuRef]);

  const getData = () => {
    setIsShowLoader(true);
    getMachineCategoryMakeWiseList((response) => {
      const { success, data, message } = response;
      setIsShowLoader(false);
      if (success) {
        setMachines(data);
      } else {
        setAlertText(message);
        setShowConfirmModal(true);
      }
    })
  }

  const handleCategories = (i) => {
    setIsShowModal(false);
    setIsActiveMake(i);
    if (i === isActiveMake) {
      setIsshowCategories(!isshowCategories);
    } else {
      setIsshowCategories(true);
      setIsshowModels(false);
    }
    if (!isshowCategories) {
      setIsshowModels(false);
    }
  }

  const handleModels = (j) => {
    setIsShowModal(false);
    setIsActiveCategory(j);
    if (j === isActiveCategory) {
      setIsshowModels(!isshowModels);
    } else {
      setIsshowModels(true);
    }
  }

  const handleAddCategory = () => {
    let list = [];
    machines.map((machine) => {
      list.push({
        'name': machine.make,
        'value': machine.make
      })
    });
    setDropdownList(list);
    setIsAddCategory(true);
  }

  const handleOnsubmit = (id, obj) => {
    setIsShowLoader(true);
    if (id === 'addCategoryModal') {
      let models = [];
      models = obj.desc2Value !== '' ? obj.desc2Value.split(',').map(item => item.trim()) : [];
      const payload = {
        'make': obj.selectedDropdown1Value,
        'category': obj.text1,
        'categoryImage': obj.file.image,
        'note': obj.desc1Value,
      }
      if (models.length) {
        payload.models = models;
      }
      createMachineCategory((response) => {
        const { success, message } = response;
        if (success) {
          getData();
          setIsAddCategory(false);
          setAlertText('Successfully added the Category !');
        } else {
          setAlertText(message);
        }
        setIsShowLoader(false);
        setShowConfirmModal(true);
      }, payload);
    }
    else if (id === 'updateCategoryModal') {
      const payload = {
        'makeId': actionData[0].makeId,
        'id': actionData[1].id,
        'categoryImage': obj.file.image,
        'note': obj.desc1Value
      }
      updateMachineCategory((response) => {
        const { success, message } = response;
        if (success) {
          getData();
          setIsUpdateCategory(false);
          setActionData([]);
          setAlertText('Successfully updated the Category !');
        } else {
          setAlertText(message);
        }
        setIsShowLoader(false);
        setShowConfirmModal(true);
      }, payload);
    } else if (id === 'addModelModal') {
      let models = [];
      models = obj.desc1Value.split(',').map(item => item.trim());
      const payload = {
        'makeId': actionData[0].makeId,
        'categoryId': actionData[1].id,
        'models': models
      }
      createMachineCategoryModel((response) => {
        const { message, success } = response;
        if (success) {
          getData();
          setIsAddModel(false);
          setAlertText('Successfully added the Models !');
          setActionData([]);
        } else {
          setAlertText(message);
        }
        setIsShowLoader(false);
        setShowConfirmModal(true);
      }, payload);
    } else if (id === 'updateMachineModal') {
      const payload = {
        id: actionData[0].makeId,
        newName: obj.text1
      }
      updateMachine((response) => {
        const { message, success } = response;
        if (success) {
          getData();
          setIsUpdateMachine(false);
          setAlertText('Successfully updated the Machine !');
          setActionData([]);
        } else {
          setAlertText(message);
        }
        setIsShowLoader(false);
        setShowConfirmModal(true);
      }, payload);
    }
  }

  const handleUpdateCategory = (machine, category) => {
    setIsShowModal(false);
    setActionData([machine, category]);
    setIsUpdateCategory(true);
  }

  const handleUpdateMachine = (machine) => {
    setIsShowMachineModal(false);
    setActionData([machine]);
    setIsUpdateMachine(true);
  }

  const handleDeleteMachineCategory = (actionData) => {
    setShowDeleteCategoryConfirmModal(false);
    setIsShowLoader(true);
    const payload = {
      'makeId': actionData[0].makeId,
      'machineCategoryId': actionData[1].id
    }
    deleteMachineCategory((response) => {
      const { success, message } = response;
      if (success) {
        getData();
        setAlertText('Successfully deleted the Machine Category !');
        setActionData([]);
      } else {
        setAlertText(message);
      }
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  }

  const handleDeleteModel = (actionData) => {
    setShowDeleteConfirmModal(false);
    setIsShowLoader(true);
    const payload = {
      'modelId': actionData[2].id
    }
    deleteModel((response) => {
      const { success, message } = response;
      if (success) {
        getData();
        setAlertText('Successfully deleted the Model !');
        setActionData([]);
      } else {
        setAlertText(message);
      }
      setIsShowLoader(false);
      setShowConfirmModal(true);
    }, payload);
  }

  return (
    <div className='u_width'>
      <div className='u_page'>
        <div className='machines__hdr'>
          <Name title={'Machines'} />
          <div className='machines__header__popup'>
            <Button className='machines__button' buttonClick={() => { handleAddCategory() }} >
              Add Category
            </Button>
            {isAddCategory ?
              <PopUp id='addCategoryModal' onCancel={() => { setIsAddCategory(false) }} commonTitle='Add Category' dropdown1List={dropdownList}
                isShowInput1={true} isShowInput6={true} isShowDescription1={true} isShowDescription2={true} input1Placeholder='Category Name'
                desc1Placeholder='Note' desc2Placeholder={'Enter Models by Comma Separated Values'} dropdown1Placeholder='Search or Add Make' isSearchDropdown={true}
                onConfirm={handleOnsubmit} btnText='DONE' />
              :
              null
            }
          </div>
        </div>
        {machines && machines.length ?
          <div className='machines'>
            <div className='machines__header'>
              MAKE :
            </div>
            {machines.map((machine, i) => {
              return (
                < div key={i}>
                  <div className={(isshowCategories && i === isActiveMake) ? 'machines__title machines__active machines__bdr' : 'machines__title'}
                  >
                    <div className='machines__btn' onClick={() => handleCategories(i)}>
                      <div className='machines__arrow-box'>
                        {(isshowCategories && i === isActiveMake) ?
                          <span className='machines__arrow machines__down-arrow'></span>
                          :
                          <span className='machines__arrow machines__right-arrow'></span>
                        }
                      </div>
                      <span>{machine.make}</span>
                    </div>
                    <i className='fa fa-ellipsis-v machines__dots' onClick={() => { setIsActiveMakeOption(i); setIsShowMachineModal(true) }}>
                      {isShowMachineModal && i === isActiveMakeOption ?
                        <div className='machines__modal' ref={menuRef}>
                          <div className='machines__items' onClick={() => { handleUpdateMachine(machine) }}> Update Machine </div>
                        </div>
                        :
                        null
                      }
                      {isShowMachineModal && i === isActiveMakeOption ?
                        <div className='machines__arrow-right'></div>
                        :
                        null
                      }
                    </i>
                    {isUpdateMachine && isActiveMake === i ?
                      <PopUp id='updateMachineModal' onCancel={() => { setIsUpdateMachine(false) }} commonTitle='Update Machine'
                        isShowInput1={true} input1Placeholder='Machine Name' input1Value={actionData[0].make}
                        onConfirm={handleOnsubmit} btnText='UPDATE' />
                      :
                      null
                    }
                  </div>
                  {i === isActiveMake && isshowCategories ?
                    <div>
                      <div className='machines__header machines__pad1'>
                        <span>CATEGORIES :</span>
                      </div>
                      {machine.category && machine.category.length ?
                        machine.category.map((category, j) => {
                          return (
                            <div key={j}>
                              <div className={isshowModels && isActiveCategory === j ?
                                'machines__title machines__pad2 machines__active machines__bdr' : 'machines__title machines__pad2'}>
                                <div className='machines__btn' onClick={() => handleModels(j)}>
                                  <div className='machines__arrow-box'>
                                    {(isshowModels && isActiveCategory === j) ?
                                      <span className='machines__arrow machines__down-arrow'></span>
                                      :
                                      <span className='machines__arrow machines__right-arrow'></span>
                                    }
                                  </div>
                                  <span>{category.name}</span>
                                </div>
                                <i className='fa fa-ellipsis-v machines__dots' onClick={() => { setIsActiveCategoryOption(j); setIsShowModal(true); }}>
                                  {isShowModal && isActiveCategoryOption === j ?
                                    <div className='machines__modal' ref={menuRef1}>
                                      <div className='machines__items' onClick={() => { handleUpdateCategory(machine, category) }}> Update Category </div>
                                      <div className='machines__items' onClick={() => { setActionData([machine, category]); setShowDeleteCategoryConfirmModal(true) }}> Delete Category </div>
                                    </div>
                                    :
                                    null
                                  }
                                  {isShowModal && isActiveCategoryOption === j ?
                                    <div className='machines__arrow-right'></div>
                                    :
                                    null
                                  }
                                </i>
                                {isUpdateCategory && isActiveCategory === j ?
                                  <PopUp id='updateCategoryModal' onCancel={() => { setIsUpdateCategory(false) }} commonTitle='Update Category'
                                    isShowDescription1={true} isShowInput6={true} updateFile={actionData[1].image}
                                    desc1Placeholder='Note' desc1TextValue={actionData[1].note} onConfirm={handleOnsubmit} btnText='UPDATE' />
                                  :
                                  null
                                }
                                {showDeleteCategoryConfirmModal && (
                                  <Confirm buttonText={'OK'} isCancelRequired={true} confirmTitle={'Are you sure you want to delete the Machine Category?'}
                                    onConfirm={() => { handleDeleteMachineCategory(actionData) }} onCancel={() => { setShowDeleteCategoryConfirmModal(false) }} />
                                )}
                              </div>
                              {
                                j === isActiveCategory && isshowModels ?
                                  <div>
                                    <div className='machines__header machines__pad3'>
                                      <span> MODELS : </span>
                                      <div className='machines__header__popup'>
                                        <Button className='machines__button' buttonClick={() => { setActionData([machine, category]); setIsAddModel(true) }} >
                                          Add Models
                                        </Button>
                                        {isAddModel ?
                                          <PopUp id='addModelModal' onCancel={() => { setIsAddModel(false) }} commonTitle='Add Models'
                                            isShowDescription1={true} desc1Placeholder={'Enter Models by Comma Separated Values'} onConfirm={handleOnsubmit} btnText='DONE' />
                                          :
                                          null
                                        }
                                      </div>
                                    </div>
                                    {category.models && category.models.length ?
                                      category.models.map((model, k) => {
                                        return (
                                          < div key={k}>
                                            <div className='machines__title  machines__pad4'>
                                              <div className='machines__btn'>{model.model} </div>
                                              <i className='fa fa-ellipsis-v machines__dots' onClick={() => { setIsActiveModel(k); setIsShowModelModal(true); }}>
                                                {isShowModelModal && isActiveModel === k ?
                                                  <div className='machines__modal' ref={menuRef2}>
                                                    <div className='machines__items' onClick={() => { setActionData([machine, category, model]); setShowDeleteConfirmModal(true) }}> Delete Model </div>
                                                  </div>
                                                  :
                                                  null
                                                }
                                                {isShowModelModal && isActiveModel === k ?
                                                  <div className='machines__arrow-right'></div>
                                                  :
                                                  null
                                                }
                                              </i>
                                            </div>
                                            {showDeleteConfirmModal && (
                                              <Confirm buttonText={'OK'} isCancelRequired={true} confirmTitle={'Are you sure you want to delete the Model?'}
                                                onConfirm={() => { handleDeleteModel(actionData) }} onCancel={() => { setShowDeleteConfirmModal(false) }} />
                                            )}
                                          </div>
                                        )
                                      })
                                      :
                                      <div className='machines__title machines__justify-text'> Models are not available ! </div>
                                    }
                                  </div>
                                  : null
                              }
                            </div>

                          )
                        })
                        :
                        <div className='machines__title machines__justify-text'> Categories are not available ! </div>
                      }
                    </div>
                    : null
                  }
                </div>
              )
            })
            }
          </div>
          : null
        }
        {showConfirmModal && (
          <Confirm buttonText={'OK'} isCancelRequired={false} confirmTitle={alertText}
            onConfirm={() => { setShowConfirmModal(false) }} onCancel={() => { setShowConfirmModal(false) }} />
        )}
        {isShowLoader ? <Loader /> : null}

      </div>
    </div >
  )
}

Machines.propTypes = {
};

Machines.defaultProps = {

}

export default Machines;
